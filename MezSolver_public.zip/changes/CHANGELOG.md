<!-- markdownlint-disable MD024 -->
# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [2.4.0] - 2026-XX-YY

### Added

- Add experimental models for partitioned mesh reconstruction, one-step
  prediction and selective state-space trajectories. The structural mechanics
  example trains them in three stages with synthetic data, material and
  region weighting, and optional wheel and seam supervision.

- `physicsnemo.mesh.spatial.sdf_normals` gives the unit direction from the
  closest surface point to each query point, and the hit face's normal for a
  query on the surface. The unified external aerodynamics recipe's
  `ComputeSDFFromBoundary` calls it. The on-surface band scales with the
  coordinates of the query and its hit face, so the recipe's normals change
  for queries closer to the wall than its former fixed band of `1.5e-5` where
  those coordinates are below one unit.

### Changed

### Deprecated

### Removed

### Fixed

### Security

### Dependencies

## [2.3.0] - 2026-11-19

### Added

- Unified external aero recipe: adds AB-UPT surface, volume, and joint
  configurations calling the library model directly, configurable independent
  point-set sampling in `DomainMeshReader`, and grouped tensor outputs for
  unequal surface/volume point counts.

- The unified external aerodynamics recipe adds experimental SMART surface and volume templates.
- The unified external aerodynamics recipe adds experimental ISLA configs on
  DrivAerML (`isla_surface`, `isla_volume` and `isla_volume_joint`) and a
  `scheduler` config group. Each ISLA config reads the whole flow-domain
  boundary and fits one 80 GB GPU at its defaults.
- Adds the `FlipBoundaryOrientation` and `BoundaryCellsToPoints` mesh
  transforms to `physicsnemo.datapipes`. The first reverses the cell winding
  and stored normals of named boundaries, and the second adds a point-cloud
  boundary at drawn cells of another boundary, with those cells' fields and
  measures.
- Adds `physicsnemo.experimental.models.ab_upt.ABUPT`, an independent
  implementation with interacting surface/volume anchors, reusable query
  contexts, input scaling and chunked forward decoding, and a finite-difference
  vorticity helper that undoes coordinate and velocity scaling.

- `physicsnemo.mesh.sampling.sample_cells_systematic` draws a fixed number of
  a mesh's cells with probability proportional to their measure, with
  Horvitz-Thompson weights for unbiased sums. The sample is spread over the
  mesh, the same in every pose, bitwise the same from run to run on CPU and
  on CUDA, and compiles to one graph.
- Indexing a mesh `Adjacency` with indices, a mask, or a slice returns the
  neighbor lists of those sources, so
  `mesh.get_point_to_points_adjacency()[points]` gives the neighbors of sampled
  points. Passing `indices=points` to the `get_*_adjacency` methods gives the
  same lists without building them for the whole mesh, and Mesh Tutorial 6
  shows how to sample points with their neighbors.
- `KNNScorer` and `DensityScorer` provide reusable out-of-distribution (OOD)
  scoring under `experimental.uq.ood`, with optional geometry descriptors.
  The examples keep scoring decisions in the application. Both scorers support
  weights-only tensor persistence. The k-nearest neighbors (kNN) scorer uses
  bounded distance blocks and leave-one-out reference scoring. The density
  scorer supports held-out calibration.
- `Mean` and `Variance` now support opt-in tensor-aware streaming with detached
  state, state combination, and `ShardTensor` reductions over declared
  observation axes.
  Existing metric constructors retain their behavior. Public `TensorAccumulator`
  and `StatisticRule` support custom statistics through `summarize`, `merge`, and
  `result` hooks, with built-in `MeanRule` and `VarianceRule`. `SumReduction`
  defines the type of the completed-reduction callback, including its `keepdim`
  argument. Fresh summaries transfer ownership to the accumulator. Variance
  merging reuses scratch storage while preserving both input states and rollback
  after failed updates. The examples cover weighted means, Gaussian process (GP)
  mixtures, Concrete Dropout, observables, and conformal calibration.
- Groups experimental scalar and field GP heads under `experimental.uq.gp`.
  Both this namespace and `experimental.uq` expose the heads without `gpytorch`;
  constructing a head raises an installation error if it is missing.
- Adds `GeoTransolver.forward_with_geometry_features` for predictions and detached
  geometry tokens in one pass, preserving the existing `forward` API.
- Strata depthwise conditioning convolutions automatically size vmap chunks
  to the 32-bit indexing limit via `DepthwiseConv(chunk_size="auto")`.
- `MeshDataset(cache_host=True)` reads each sample once and serves repeats from
  memory, for fitting runs on a few samples. `DomainMeshReader` gains
  `interior_n_points_range` to draw the interior point count for each sample,
  and `CenterMesh` gains `store_center_as` to keep the subtracted center in
  `global_data`.
- Adds a Rotor37 compressor blade example with GeoTransolver
  (`examples/cfd/rotor37_geotransolver`)
- Adds an experimental, independently implemented SMART operator with sampled
  geometry encoding, reusable latent contexts, and chunked field decoding.
- Adds `physicsnemo.experimental.uq.conformal`: post-hoc conformal prediction
  for spatio-temporal fields with `PointwiseCalibrator`,
  `FunctionalBandCalibrator`, `RiskControlCalibrator`, `ConformalPredictor`,
  `CoverageAccumulator`, `AbsoluteErrorScore`, `NormalizedErrorScore`,
  `QuantileRegressionScore`, and `AuxScale`. Custom scores subclass
  `NonconformityScore` and register with `register_score`; `check_score`
  tests them.
- Adds `physicsnemo.experimental.nn.shell_contact`: shell contact as pure
  functions over tensors (node-to-facet pair search with a Warp BVH broad
  phase and fused Warp narrow phase, crossing-aware signed gaps, edge
  features and tapers, penetration depths and rigid-wall clamp), and
  `physicsnemo.experimental.nn.geodesic_knn` (k-nearest neighbourhoods of a
  mesh along its edges; Euclidean ones use `physicsnemo.nn.functional.knn`).
- Adds `physicsnemo.experimental.models.deformer`: the DeFormer
  network (a GeoTransolver/FLARE backbone with static kNN-attention
  stages and a fused kernel) and its contact-aware corrector (message passing
  on the structural edges and on the contact edges discovered on a predicted
  shape).
- Adds the DeFormer crash surrogate to `examples/structural_mechanics/crash`:
  the time-conditional network and corrector wrappers, the three full-vehicle Yaris
  recipes (`px_yaris_deformer`, `px_yaris_deformer_corrector`,
  `px_yaris_geotransolver`), the body-in-white recipe `biw_yaris_deformer`
  and target-relative penetration metrics.

- Adds standalone FLARE++ attention and model APIs, with input-conditioned
  dynamic routing, plus a ``GALE_FPP`` backend for using the same mixer inside
  GeoTransolver.
- Adds `physicsnemo.datapipes.keys` and routes every config-driven field name
  in `physicsnemo.datapipes` through it, so a `"."` in a YAML field name
  (`"solution.pressure"`) addresses a leaf inside a nested `TensorDict`.
  Nested `Mesh` data no longer needs to be flattened before use.
- `DistributedManager.initialize(timeout=...)` accepts numeric seconds or a
  `timedelta` for the default process-group timeout. Explicit values override
  `PHYSICSNEMO_DIST_TIMEOUT_S`; unset or empty configuration keeps PyTorch's
  backend default. Invalid timeouts are rejected before initialization state
  changes, allowing corrected configuration to be retried.
- `MeshToDomainMesh` in `cell_centroids` mode records each source cell's
  complete effective measure on the interior under the mesh-owned
  `_effective_measure` point-data key, so
  integrals and weighted losses over the query points remain possible after
  the cells are gone.
- Unified external aero recipe: a sample can carry several prediction point
  sets with their own targets (`target_sources`), so branch models
  (`output_groups`) and single-decoder models (`output_sets`) can train on
  volume and surface points jointly; model configs can add such a set to any
  dataset with `extra_task`.
- Unified external aero recipe: `NonDimensionalizeByMetadata` gains
  `scale_geometry` so chained instances scale the geometry once; inference
  re-dimensionalizes with the field maps of every instance.
- Extends the diffusion module to support flow matching. The new API
  surface covers three pieces:
  - New losses in `physicsnemo.diffusion.metrics.losses` train against a
    flow/velocity target: `FlowMatchingLoss`, plus `WeightedFlowMatchingLoss`
    for an element-wise weight such as a binary mask. Their
    `MultiDiffusionFlowMatchingLoss` and
    `MultiDiffusionWeightedFlowMatchingLoss` counterparts provide patch-based
    flow-matching training on large spatial domains. `MultiDiffusionModel2D`
    and `MultiDiffusionPredictor` support both patch-based diffusion and flow
    matching during training and inference.
  - A dedicated `RectifiedFlowNoiseScheduler` in
    `physicsnemo.diffusion.noise_schedulers` provides a rectified-flow
    schedule.
  - Module-wide support for flow predictors, enabled by new conversion
    functions in `LinearGaussianNoiseScheduler` (`x0_to_flow` / `flow_to_x0`
    / `score_to_flow` / `flow_to_score`) and the corresponding conversion
    callbacks everywhere conversions between prediction types are necessary.
- Adds `physicsnemo.experimental.models.isla.ISLA` (Invariant Slice Attention),
  an experimental mesh-native surrogate for steady boundary-value problems that
  takes the boundary as named meshes, and `case_scales`, which gives other
  models ISLA's length and field scales. ISLA's outputs follow rotations,
  reflections and translations of the problem exactly, up to roundoff, except
  on some symmetric or nearly symmetric boundaries described on its
  documentation page.
- `physicsnemo.mesh.spatial` exports `canonical_frame`, the principal-axis frame
  that a weighted point set carries with it, and `frame_coordinates`, the
  points' coordinates in that frame.
- `ClusterTree.find_point_interaction_pairs` takes targets of shape `(R, M, D)`
  with `root_rows`, the row each root's tree reads, so one call walks a forest
  whose trees each use their own coordinates.
- Adds `ExponentialEulerSolver`, `EDMStochasticExponentialEulerSolver`,
  `DPMPlusPlus2M`, and `DPMPlusPlus2MUniC2` to
  `physicsnemo.diffusion.samplers`. `ExponentialEulerSolver` supports
  DDIM-like sampling for distilled few-step models, its stochastic
  counterpart adds EDM-style churn and configurable re-noising,
  `DPMPlusPlus2M` provides efficient second-order sampling, and
  `DPMPlusPlus2MUniC2` adds a UniC-2 corrector stage that raises
  DPM-Solver++(2M) to third order while keeping one denoiser evaluation
  per step. The solvers share an extended semi-linear callback API
  (`bias_fn`, `bias_int_fn`, `slope_fn`); users can select all four
  solvers by string key through `physicsnemo.diffusion.samplers.sample`.
- The `examples/weather/regional_weather_diffusion` recipe can train diffusion
  models with rectified flow matching (`training.loss.type: flow_matching`) and
  sample them in validation and `inference.py`. Adds the
  `replication_corrdiff_conus` config and dataset for replicating the
  CorrDiff-ERA5-HRRR downscaling model over the contiguous US.
- `ClusterTree.find_dual_interaction_pairs(source_admissible=...)` marks source
  nodes that must never be approximated by their aggregate, such as nodes
  whose normals differ too much.
- `ClusterTree.find_point_interaction_pairs` builds a Barnes-Hut plan for
  individual target points by a single-tree walk (every point reads nearby
  sources exactly and distant nodes through their aggregates). For scattered
  targets such as volume prediction points it replaces
  `find_dual_interaction_pairs(expand_far_targets=True)`, whose criterion
  charges the target leaf's own extent: on a 200k-face car with 200k volume
  points the dual plan held 1.6e9 pairs at `theta=0.5` and the point plan
  holds 1.5e8.
- The PhysicsNeMo-Mesh API reference documents `physicsnemo.mesh.fields`
  (`RankSpec` and `FieldSchema`) and the `physicsnemo.mesh.primitives` catalog.
- `ClusterTree.merge` joins trees into one forest, whose `root_ids` list the
  root of each tree. Every traversal starts from all of them, so one
  traversal plans a tree against every tree of a forest, on either side.
- `ClusterTree.from_points`, the new `ClusterTree.from_point_groups` (one tree
  per group of points, and their forest) and
  `ClusterTree.find_point_interaction_pairs` run in Warp kernels on CUDA by
  default (`implementation=`), with one host synchronization instead of one per
  tree level, and give the same trees and plans. The point plans now list each
  target's entries together, and `count_only=True` counts them without making
  the plan.
- `radius_search` accepts points with 1 or 2 coordinates, as well as 3, with
  both backends. The torch backend accepts any number of coordinates, and
  points with more than 3 use it by default.
- `ShardTensor` ring attention, ring kNN and ring ball query run on functional
  collectives; ring attention works under `torch.compile` as an eager
  graph-break region, with uneven sequence shards and attention masks
  sharded like the queries. In-place `detach_` on a `ShardTensor` is
  supported.
- `radius_search` on sharded inputs works under `torch.compile`.
- Domain-parallel (rank-local) reading in the datapipes: `ZarrReader`,
  `TensorStoreZarrReader`, `MeshReader` and `DomainMeshReader` accept a
  `domain_parallel` dict and a 1-D `device_mesh`; each rank reads only its
  rows and the dataset assembles `Shard(0)` ShardTensors on the device.
  Custom readers opt in by implementing `Reader._load_sample_domain_parallel`
  with the exported `DomainParallelConfig` / `resolve_leaf_placements`.
- The unified external aero recipe trains with optional domain parallelism
  (`domain_parallelism.domain_size`), reading samples sharded and running the
  model on ShardTensors over a domain x data-parallel device mesh.

- `physicsnemo.mesh.repair` adds `stitch_t_junctions`, which closes the
  zero-width gaps where a vertex lies on another triangle's edge, and
  `split_nonmanifold_edges`, which pairs the triangles at each edge shared by
  three or more of them and drops the unpaired fins and the pillows (coincident
  triangles wound opposite ways).
- `physicsnemo.mesh.validation` adds `find_self_intersections`, which finds the
  pairs of crossing triangles in a 3D surface. `validate` runs it when
  `check_self_intersection=True` and skips meshes it does not apply to.

### Changed

- `repair_mesh` also removes duplicate cells and stitches T-junctions of
  triangle meshes by default, and `split_nonmanifold_edges=True` also drops fins.
  Its default tolerances are now relative to the mesh's size, and an explicit
  `tolerance` also sets the stitching distance, with `area_tolerance` then
  defaulting to its square on surfaces.
- Renames the body-in-white crash recipes `crash_geoflare_oneshot` and
  `crash_geotransolver_oneshot` of `examples/structural_mechanics/crash` to
  `biw_yaris_geoflare_oneshot` and `biw_yaris_geotransolver_oneshot`: every
  recipe of the example now names its dataset (`px_yaris_*` full vehicle,
  `biw_yaris_*` body-in-white, `bumper_*` bumper beam).
- &#9888;&#65039; **BC-impact (crash example global features):** the datapipe of
  `examples/structural_mechanics/crash` standardizes the global features with
  train-split statistics stored in `stats/global_stats.json`, which changes the
  inputs of the three bumper recipes. A run directory written before this
  change holds checkpoints but no such file: `train.py` refuses to resume it
  instead of recomputing the statistics and continuing on rescaled inputs, and
  `inference.py` needs the file. Start such runs afresh.
- &#9888;&#65039; **BC-impact (crash example edge statistics):** the graph datapipe
  of the crash example divides the first sample's contribution to the edge
  statistics by the sample count like every other sample's, which fixes an
  edge-length standard deviation that collapsed to about 1e-4. Existing runs
  keep the values stored in their own `stats` directory; new runs compute the
  corrected ones, so their models are not interchangeable with the old runs'.
- &#9888;&#65039; **BC-impact (crash example frame names):** `inference.py` of the
  crash example writes the predicted frames as `frame_001` to `frame_T`
  (prediction `k` belongs to frame `k + 1`) instead of starting at
  `frame_000`; `post_processing/compute_l2_error.py` reads the new names.
- &#9888;&#65039; **BC-impact (diffusion metric imports):** Cleans up
  `physicsnemo.diffusion` dependencies and imports. General-purpose metrics can
  no longer be imported from `physicsnemo.diffusion.metrics`. Use the following
  modules instead:
  - `rank_probability_score`: `physicsnemo.metrics.general.calibration`
  - `crps`, `kcrps`: `physicsnemo.metrics.general.crps`
  - `StreamingStatistic`, `Mean`, `Variance`:
    `physicsnemo.metrics.general.ensemble_metrics`
  - `entropy_from_counts`, `relative_entropy_from_counts`:
    `physicsnemo.metrics.general.entropy`
  - `Histogram`, `cdf`, `histogram`, `normal_cdf`, `normal_pdf`:
    `physicsnemo.metrics.general.histogram`
  - `power_spectrum`: `physicsnemo.metrics.general.power_spectrum`
  - `wasserstein_from_cdf`, `wasserstein_from_samples`:
    `physicsnemo.metrics.general.wasserstein`

  For example, use `from physicsnemo.metrics.general.crps import crps`.
  Replace `EnsembleMetrics` imports with
  `from physicsnemo.metrics.general.ensemble_metrics import StreamingStatistic`.
  Removed imports emit a warning and an error with the replacement import.
  `wasserstein_from_normal` remains available through both existing import paths.

- Partitioning a graph across GPUs (`partition_graph_with_id_mapping`, behind
  `DistributedGraph` and GraphCast's distributed mode) no longer loops over
  destination nodes in Python. A 1-million-node grid now takes well under a
  second instead of half a minute or more.
- `ClusterTree` builds tighter trees by default (`split="morton"`), so
  Barnes-Hut plans need 2-4x fewer interactions at the same `theta`.
  `split="midpoint"` gives the previous trees.
- GLOBE's default `theta` is 1.5 (was 1.0). With the new trees, DrivAerML
  training reaches about 40% lower validation loss in the same time.
- GLOBE's default `expand_far_targets` is `True` (was `False`), as in its
  examples.
- `ClusterTree.compute_source_aggregates` is 20-30x faster, and
  `ClusterTree.find_dual_interaction_pairs` is up to 1.7x faster with 40% less
  peak memory. The plan's interactions are no longer sorted by source.
- GLOBE's `BarnesHutKernel` needs less memory to train: an 80k-face DrivAerML
  training step no longer runs out of memory.
- An eager GLOBE training step on 10k-face DrivAerML samples runs 2.2x
  faster, and `torch.compile` builds GLOBE faster, with the same outputs.
- GLOBE's `BarnesHutKernel.forward` takes `near_chunk_count`, a number of
  chunks, in place of `near_chunk_size`, and no longer takes
  `source_aggregates`.
- The `source_data` and `global_data` of GLOBE's kernel classes must hold
  exactly the declared fields, under nested keys: a flat key such as
  `"grp.v"` now raises a `KeyError` that names the wrong fields.
- GLOBE returns nested output fields in sorted key order, such as
  `("flow", "nut")` before `("flow", "u")`.
- The GLOBE DrivAerML example now trains for 450 epochs on one node, with the
  model and training configuration of the GLOBE paper's DrivAerML results.
  `--n-epochs` and `--lr-decay-epochs` replace `--patience-steps`, and
  checkpoints from earlier versions of the example do not resume.
- `ClusterTree.compute_source_aggregates` packs its source data with
  `TensorDict.pack`, so source data with leaves of several dtypes now raises
  a `TypeError` instead of being promoted.
- Refresh core, optional, development, and container dependency versions.
  Require PyTorch 2.13 or newer;
  use PyTorch 2.13's CUDA 12.9 wheels for the CUDA 12 backend. NATTEN
  extras select PyTorch 2.13 to match their prebuilt kernels. Python support remains
  3.11 through 3.14.

- Mesh connectivity sorts the vertices of its short index tuples (edges,
  faces, cells) with a sorting network of elementwise minima and maxima on
  large CUDA inputs, instead of `torch.sort`. On an NVIDIA GB300, facet and
  boundary extraction, edge graphs, point adjacency, and manifold checks of
  10M-cell meshes are 3-5x faster, butterfly subdivision 2.3x, and cell
  adjacency, cleaning, and the DEC Laplacian 1.2-2.1x. Results are unchanged.
- `physicsnemo.mesh.fields` is rebuilt around two types. `RankSpec` (`rank`,
  `symmetric`, `parity`; `shape(n_spatial_dims)`, `numel(n_spatial_dims)`) is
  one field's transformation law; `FieldSchema` is an insertion-ordered
  mapping from dotted field names to `RankSpec`, parsed once at a model's
  boundary with `FieldSchema.parse` (nested groups and dotted names flatten
  alike) and queried with `.ranks`, `.count(rank)`, `FieldSchema.key(name)`,
  and `.check(tensordict, label=...)`. Both are read-only `dict`s, so a
  declaration serializes to JSON as written and model checkpoints can record
  them directly. Validation is construction, so an invalid schema cannot
  exist. A field is declared as a `RankSpec` or a mapping of values,
  `{"rank": n}` (YAML: `pressure: {rank: 0}`); a mapping of mappings is a
  nested group. Integer leaves are no longer accepted.
- Mesh geometry, curvature, sampling, mesh generation, LSQ gradients, and
  the PyTorch backends of the deformation functionals solve their small
  per-cell determinants, inverses, and least-squares problems in closed form
  instead of with batched `torch.linalg` calls. Vertex angles, Gaussian
  curvature, and quality metrics become up to 1,000x faster on GPU, and many
  mesh operations 4-130x faster on CPU.
- Mesh vertex angles, dual volumes, curvature, quality metrics, and cell and
  point normals use up to 3.4x less peak memory, and gradients through cell
  centroids and normals are faster on GPU. Results are unchanged up to
  rounding.
- Mesh LSQ gradients (`Mesh.gradient`, `curl`, `divergence`,
  `compute_point_derivatives`, `compute_cell_derivatives`, and the torch
  backend of `physicsnemo.nn.functional.mesh_lsq_gradient`) solve the float32
  systems of all points or cells at once rather than one neighbor count at a
  time, and the derivatives of several fields share their least-squares
  systems. On a GB200, the gradient of a 5.1M-tet mesh is 2.4x faster and
  that of meshes up to 1.3M tets 3.4-3.7x faster; the derivatives of eight
  scalar fields on a 1M-tet mesh are 13x faster. Results are unchanged up to
  rounding. The intrinsic gradient of a float64 field on a float32 mesh now
  returns a result of float32 accuracy instead of raising a dtype error.
- GLOBE's field declarations are renamed after the schemas they hold:
  `output_field_ranks`, `boundary_source_data_ranks` and `global_data_ranks`
  become `output_schema`, `boundary_source_schemas` and `global_schema`
  (kernels: `output_schema`, `source_schema`, `global_schema`), each also the
  attribute holding the parsed `FieldSchema`. GLOBE raises
  `NotImplementedError` for fields it does not implement (rank 2 and above,
  pseudotensors) instead of silently dropping or misreading them. The GLOBE
  examples and the unified external-aerodynamics recipe configs are updated.
- Cell-to-cell adjacency pairs the cells of each shared facet in one
  vectorized pass, adjacency offsets come from a binary search instead of
  `bincount`, and adjacencies carry their device, so cached adjacencies are
  reused without revalidation. Cell adjacency and the dual graph are 1.4-1.6x
  faster with 30% less peak memory, and synchronize CUDA 5 times instead of 38.
- Mesh adjacencies, facet extraction, manifold checks, and `fix_orientation`
  use up to 3x less peak memory, with unchanged results.
- `physicsnemo.mesh.Mesh`, `DomainMesh`, `Adjacency`, `BVH`, `ClusterTree`,
  `DualInteractionPlan`, and `SourceAggregates` now inherit directly from
  `TensorClass` instead of using the `@tensorclass` decorator. Existing
  constructor defaults and `Mesh[m, s]` runtime specialization remain
  available, and nested mesh types survive memmap round trips. The memmap
  layout is unchanged: existing `.pmsh` and `.pdmsh` files remain readable, and
  new files are byte-identical to those written with the decorator.
- `from_pyvista(point_source="cell_centroids", manifold_dim=1)` builds the
  dual graph of line, triangle, and tetrahedral meshes 25-30x faster, with
  identical output. With the default `force_copy=False`, `to_pyvista` output
  of 1D and 3D meshes now shares cell storage with the `Mesh`, as 2D output
  already did.
- Mesh facet extraction, repair, merging, smoothing, subdivision, and quality
  metrics avoid CUDA synchronizations hidden in indexing with Python lists,
  blocking copies of small host tables, boolean masks, and one `.item()` per
  count. Laplacian smoothing synchronizes at most 4 times instead of about 30,
  independent of the number of iterations, and `remove_degenerate_cells` is
  about 5x faster. Results are unchanged.
- Loop and butterfly subdivision evaluate their edge rules for every edge and
  select with `torch.where`, instead of compacting boundary and interior edges
  with boolean masks. Butterfly subdivision synchronizes CUDA 3 times instead
  of 13, Loop subdivision 9 instead of 13, and both are 10-15% faster.
- Mesh subdivision, `cell_data_to_point_data`, `point_data_to_cell_data`, and
  `Mesh.merge` need up to 2.9x less peak memory, with unchanged results.
- Mesh integration uses a shared `_effective_measure` field for complete cell
  and point measures. Cell measures fall back to geometry; point measures are
  explicit and independent of connectivity. `Mesh.integrate_samples` evaluates
  point quadrature separately from existing cell and vertex-field integration.
  Sampling, centroid conversion, geometric transformations, subdivision, and
  GLOBE use the mesh-owned measure API. Point measures carry their represented
  dimension so geometric scaling preserves their physical units.
- Promotes the volumetric `DiffusionUNet3D` and its reusable `Conv3D`,
  `GroupNorm3D`, `UNetAttention3D`, and `UNetBlock3D` layers from experimental
  to stable production APIs in `physicsnemo.models.diffusion_unets` and
  `physicsnemo.nn`. The promoted APIs now carry backward-compatibility
  guarantees and output/checkpoint non-regression coverage. Existing
  experimental import paths remain as deprecated compatibility shims.

  **Migration from 2.2.x:** meshes saved with `cell_data["_measure_weights"]`
  must be regenerated or converted once before integration:

  ```python
  from physicsnemo.mesh.calculus import set_cell_measures

  if "_measure_weights" in mesh.cell_data:
      weights = mesh.cell_data.pop("_measure_weights")
      set_cell_measures(mesh, mesh.cell_areas * weights)
  ```

  Replace `compose_measure_weights` calls with `scale_measures`. Consumers
  should read complete measures with `cell_measures` instead of multiplying
  `cell_areas` by `cell_measure_weights`. Update stored-field mappings from
  `cell_data._measure_weights` to `cell_data._effective_measure` and remove any
  subsequent multiplication by geometric areas.

- LSQ point gradients on large surface meshes are about 2x faster on GPU, and
  LSQ gradients (`Mesh` and `physicsnemo.nn.functional.mesh_lsq_gradient`)
  synchronize the GPU much less often. LSQ and DEC derivatives also need less
  peak memory.

- `Mesh.slice_points` picks its cell-remapping algorithm by mesh shape: the
  full-mesh lookup table as before, or a binary search over the kept ids when the
  mesh has far more points than cell-vertex entries (a reader keeping a block of
  cells out of a mesh with hundreds of millions of vertices). Index
  normalization avoids allocating a full-mesh range and preserves empty slices,
  integer indices, and boolean masks. Point fields use ordinary indexed gathers.
- `Darcy2D` solves with multi-grid red-black successive over-relaxation
  instead of Jacobi iteration, converging in far fewer iterations and about
  100x closer to the discrete solution at the default tolerance. Batches whose
  SOR solve diverges are re-solved with Gauss-Seidel. `Darcy2D` now raises a
  `ValueError` unless `0 < min_permeability <= max_permeability` and
  `max_permeability / min_permeability <= 4`; above that ratio the
  finite-difference scheme does not converge.
- Extends `LinearGaussianNoiseScheduler` with two methods.
  `get_linear_denoiser` accepts `prediction_type` and `denoising_type`, and
  returns bias, antiderivative, and slope callables for the new exponential
  and multistep solvers. `snr` exposes the schedule's signal-to-noise ratio,
  used as the multistep extrapolation coordinate by `DPMPlusPlus2M` and
  `DPMPlusPlus2MUniC2`.

- `translate`, `rotate`, `scale`, and their `DomainMesh` and datapipe
  counterparts no longer synchronize CUDA for Python-number arguments, string
  axes, rotations, and scalar scales, so they return without waiting for queued
  GPU work. `transform` gains `assume_similarity` and `rotate` gains
  `assume_valid_axis`, to skip the remaining runtime checks for general
  matrices and device-tensor axes. Cached normals are mapped with one small
  inverse instead of `solve_ex` with millions of right-hand sides, whose slow
  path for pivoting matrices made `RandomRotateMesh(mode="uniform")` take 1.3 s
  on the 17.7M-triangle DrivAerML surface (6.5 ms now, on a GB300).

- The `tolerance` of `sample_data_at_points`, `find_containing_cells`, and
  `find_all_containing_cells` is now relative. Barycentric coordinates must
  still be `>= -tolerance`, but the distance from a point to a cell's affine
  hull is now limited to `tolerance` times the largest absolute coordinate of
  the mesh, instead of `tolerance` in mesh units. Results no longer depend on
  the mesh's length unit and are identical when the mesh and query points are
  scaled by a power of two.
- Mesh BVH queries, and with them `validate`, `Mesh.clean()`, point
  containment and sampling, use up to 2.7x less peak memory. Results are
  unchanged.
- `fix_orientation` orients cells of any dimension and is 6x faster on the
  DrivAerML surface. Cells that fill their space, such as tetrahedra in 3D,
  come out with positive volumes. Its stats add `n_cells_flipped`, with
  `n_faces_flipped` kept as an alias, and `n_non_orientable_components`.
- `repair_mesh(fix_orientation=True)` orients every mesh except point clouds,
  instead of only surfaces in 3D.

- `compute_mesh_statistics` reads all statistics in one device-to-host
  transfer instead of about 20 `.item()` calls.
- `MeshReader` and `DomainMeshReader` map sample files copy-on-write, so
  editing a loaded sample in place no longer changes the dataset on disk.
  Readers on Lustre also no longer take write locks.
- Moving or copying a mesh with cached adjacencies no longer synchronizes a
  CUDA device.
- `BoundingBoxFilter` takes about half as long on CPU. On a GPU it
  synchronizes once per coordinate key, instead of once per filtered tensor.
- Every PhysicsNeMo-Mesh API page now opens with a figure, and the nine
  tutorials in `examples/minimal/mesh` are reorganized from a first mesh to ML
  pipelines. New sections show how to use the edge graph of a mesh, a
  `Mesh[1, n]`, in graph network models.
- The `perturbed_grid` primitive takes `perturbation_scale` as a fraction of
  the grid spacing (was an absolute length), so its default no longer folds
  cells, even on fine grids.
- `CenterMesh` materializes the center of mass on sharded meshes so the offset
  stays a plain tensor.
- `index_select` and integer-tensor indexing on a `ShardTensor` exchange only
  the requested rows instead of all-gathering the source; no host sync, and
  `torch.compile` safe.
- Unified external aero recipe: when a dataset puts its targets at cell
  centroids, as the surface datasets do, the training loss and the metrics
  weight each target point by its cell's area (or volume), so they no longer
  depend on how finely the mesh resolves each region. Set
  `measure_weighted=false` to count every point alike, as before.
- The stream-based ring helpers `perform_ring_iteration_async` and
  `get_comm_stream` are removed; use `perform_ring_iteration_funcol` with
  `wait=False` and `finish_ring_iteration` for overlap.
- Promotes GLOBE out of `experimental` to `physicsnemo.models.globe.GLOBE`, the
  package's only export. Legacy import shims keep the old
  `physicsnemo.experimental.models.globe` paths and saved checkpoints working
  and emit a `LegacyFeatureWarning`.
- `physicsnemo.mesh.generate.marching_cubes` keeps a CUDA field on its GPU and
  returns the mesh on the field's device, so a CUDA field no longer makes a
  round trip through host memory and `coords` on a CUDA device no longer raise
  a device error. CPU fields run as before.

### Deprecated

- `EnsembleMetrics`, the base class of `Mean`, `Variance`, and `Histogram`, is
  renamed `StreamingStatistic`. `EnsembleMetrics` remains an alias of the same
  class, so existing subclasses and `isinstance` checks keep working; importing
  it emits a `LegacyFeatureWarning`.
- `weighted_multinomial` and `WeightedMultinomial` moved from
  `physicsnemo.nn.functional` to `physicsnemo.utils`. Importing them from
  `physicsnemo.nn.functional` still works but emits `LegacyFeatureWarning`.
- Unified external aerodynamics recipe: `training.loss_type: rmse` is
  deprecated in favour of `relative_mse`, which names what it always
  computed (target-normalized relative MSE, no square root) and delegates
  to `physicsnemo.metrics.general.relative_error`. `rmse` still works and
  warns.
- The `physicsnemo.experimental.models.globe` import path is deprecated.
  Import GLOBE from `physicsnemo.models.globe` instead.

### Removed

- Removes `physicsnemo.deploy`, deprecated in this release. Its only callers
  were PhysicsNeMo's own ONNX tests, which now carry the two functions they
  used. Instead of `export_to_onnx_stream`, call
  `torch.onnx.export` with an `io.BytesIO` target; instead of
  `run_onnx_inference`, run the result in an `onnxruntime.InferenceSession`.
- `physicsnemo.experimental.guardrails`. Scoring moved to
  `physicsnemo.experimental.uq.ood`; thresholds and responses now live in
  example recipes. Replacements:
  - `GuardedGeoTransolver`, `attach_ood_guard`, `OODGuard`, `OODGuardConfig`:
    call `GeoTransolver.forward_with_geometry_features`, pool the tokens,
    and score them with `KNNScorer`. Global-parameter bounds become an explicit
    input check. See `examples/minimal/uq/feature_scoring.py`. A saved
    `GuardedGeoTransolver` keeps its GeoTransolver weights under the `model.`
    prefix; refit the scorer on reference features.
  - `GeometryGuardrail`, `GeometryDensityModel`, `TorchPCEDensityModel`:
    `DensityScorer(method="gmm" | "pce")` on descriptors from
    `physicsnemo.experimental.uq.ood.geometry.extract_features`. See
    `examples/minimal/guardrails/geometry_validation.py`, which also replaces
    `load_features_from_dir`.
  - The other geometry utilities keep their names under
    `physicsnemo.experimental.uq.ood.geometry`; `FEATURE_VERSION` is now `v1.1`.
- The `physicsnemo.experimental.uq.variational_gp_head` and
  `physicsnemo.experimental.uq.field_variational_gp_head` modules. Import the
  heads from `physicsnemo.experimental.uq` as before, or from
  `physicsnemo.experimental.uq.gp`.
- `physicsnemo.experimental.models.globe.utilities`, whose TensorDict helpers
  GLOBE no longer uses.
- `physicsnemo.mesh.fields`: `RankSpecDict`, `flatten_rank_spec`,
  `rank_counts`, `ranks_from_tensordict`, and `validate_data_contains_ranks`,
  replaced by `FieldSchema` (see Changed). Importing one of them from
  `physicsnemo.mesh` or `physicsnemo.mesh.fields` raises an `ImportError` that
  names its replacement.
- Removes the opt-in `physicsnemo.compat` import-alias layer and the
  `PHYSICSNEMO_ENABLE_COMPAT` environment variable. The layer mapped pre-v2.0
  module paths onto their v2.0 locations; three minor releases later, callers
  should import from the current paths listed in `v2.0-MIGRATION-GUIDE.md`.
  Checkpoint loading is unaffected.
- Removes `physicsnemo.utils.mesh`, deprecated since 2.1 with removal scheduled
  for 2.2. The `vtk` and `stl` entries leave the `utils-extras` extra with it.
  Replacements:
  - `sdf_to_stl(field, threshold)`: `marching_cubes` from
    `physicsnemo.mesh.generate` returns a `Mesh`; save it with `to_pyvista`
    from `physicsnemo.mesh.io`, for example,
    `to_pyvista(marching_cubes(torch.as_tensor(field), threshold)).save("out.stl")`.
  - `combine_vtp_files(files, out)`:
    `pyvista.merge([pyvista.read(f) for f in files]).save(out)`.
  - `convert_tesselated_files_in_directory`: `pyvista.read(src).save(dst)` per
    file; PyVista reads and writes OBJ, VTP, and STL.

### Fixed

- `load_checkpoint` keeps a resumed optimizer's step counts on the CPU, where a
  fresh AdamW keeps them, unless the optimizer is fused or capturable. Step
  counts on the GPU forced host syncs in every later eager optimizer step and
  slowed resumed training.
- At `tree_read_theta > 0`, ISLA's reference boundary read holds each cluster's
  cell weights fixed in its means, as the fused CUDA kernel does, so both give
  the same derivatives in the boundary's vertices. They used to disagree there.
- `from_pyvista` splits again each polygon that VTK splits wrongly, into a fan
  of triangles around one new point at its center, so its output can have more
  points than the input. A closed polygon surface used to convert with holes,
  repeated triangles or stray triangles.
- ISLA's `query_chunks` works when the cells' measures require gradients,
  whether they come from the boundary vertices or from a given
  `_effective_measure`. It used to raise in a later chunk's backward pass or
  in `QueryChunks.backward`.
- Distributed `load_checkpoint` restores the optimizer state on every rank when
  `optimizer_model` is not distributed, such as a small model trained beside an
  FSDP model. Before, only rank 0 restored it, and the other ranks silently kept
  a fresh optimizer.
- `fill_holes` winds each fill like the surrounding surface, fills holes that
  pass through a shared vertex, leaves zero-area slits to
  `stitch_t_junctions`, and fills flat holes without folded triangles.
- `Mesh.save` and `DomainMesh.save` can write a mesh read from disk to a new
  path. They used to raise unless `copy_existing=True` was passed, because the
  loaded tensors are memory-mapped to the original files.
- A stack of mesh `Adjacency` objects saved with `memmap` or `TensorDict.save`,
  alone or inside a stacked `TensorDict`, now loads. Loading used to fail the
  checks for a single adjacency.
- The container build compiles NATTEN from source with C++20 when no
  prebuilt NATTEN wheel is supplied, so it builds on PyTorch 2.15 base
  images, whose headers require C++20.
- The container build compiles pyg-lib from source without the uv cache, so
  it no longer reuses a pyg-lib wheel built against an older PyTorch, which
  failed to load with an undefined symbol after a base image upgrade.
- `Mesh.with_cells` and `fix_orientation` keep the effective measure and area
  of each cell whose vertices are only reordered, as when flipping a winding,
  instead of rescaling them by float32 roundoff or raising on zero-area cells.
- `DistributedManager` now initializes on CPU-only hosts, where PyTorch rejected
  its CPU `device_id` and a missing local rank raised `ZeroDivisionError`.
  `cleanup()` no longer raises after a failed initialization.
- The GLOBE DrivAerML example integrates the friction force on the car with
  the right sign. Its drag coefficients were about 0.055 too low.
- The unified external aero recipe integrates force coefficients with the
  right signs for DrivAerML and HighLiftAeroML. A dataset YAML now declares
  where its surface normals point and which side its wall shear stress acts
  on (`surface_normals_point`, `wall_shear_acts_on`).
- `initialize_mlflow` offline mode logs to SQLite (`./mlruns/mlflow.db`)
  instead of the file store that current MLflow rejects.
- `docs/test_scripts` run again on current PhysicsNeMo.
- `physicsnemo.metrics.cae.cfd.compute_tke_spectrum` no longer raises
  `UnboundLocalError` when `length` is passed; the domain length now sets the
  grid spacing used for the wavenumbers.
- The GLOBE DrivAerML example trains under `torch.compile` again on PyTorch 2.13
  and 2.14. It and the AirfRANS example now set
  `torch._dynamo.config.specialize_float`, which avoids a Dynamo crash in GLOBE's
  Padé networks (pytorch/pytorch#193194).
- Stabilizes PCE density scores for collinear features by fitting polynomial
  covariance/precision in float64. Rejects non-finite density scores before
  percentile decisions and isolates scorer initialization from prediction RNGs.
- Preserve unreduced ShardTensor placement dimensions in `sum` and `mean`
  when `keepdim=True`, including independently sharded simulation and spatial axes.
- `torch.compile` with ShardTensor: neighborhood attention (`na1d`/`na2d`/
  `na3d`) keeps its halo exchange when compiled, `select` handles a negative
  `dim`, dynamic shapes no longer fail in the spec hash, a plain DTensor
  operand next to a ShardTensor uses the DTensor fallback, and a plain
  parameter used with a ShardTensor gets a reduced gradient as in eager.
- Multi-node jobs launched with `srun` no longer hang in
  `DistributedManager.initialize()` when Slurm starts rank 0 on a different node
  from the one that ran `srun`. The rendezvous now uses the job step's first node.
- `DistributedManager.initialize()` works in a Slurm batch script run without
  `srun`. It used to find no rendezvous address there and raise a `TypeError`.
- `Mesh.get_point_to_points_adjacency()`, `get_facet_mesh()`, and
  `get_boundary_mesh()` compile with `torch.compile(fullgraph=True, dynamic=True)`.
  Facet extraction now specializes on the cell width instead of passing a
  symbolic size to `itertools.combinations`.
- Compiled code that reads `Mesh` geometric properties, such as `cell_areas`
  or curvatures, no longer recompiles when the input mesh's cache differs, and
  no longer writes into that cache. `set_cell_measures` stores a copy of the
  cached `cell_areas`, so a measure never aliases it. `physicsnemo.mesh` now
  checks whether its own code is being traced, because since torch 2.13
  `torch.compiler.is_compiling()` is True in every thread during a compile,
  which made data-loading threads drop caches and skip validation.
- `Mesh` geometric properties, curvatures, and the calculus operators give
  correct gradients when the points require gradients, even after a read under
  `torch.no_grad()`, and a second `backward()` on the same mesh no longer
  fails. Such meshes now compute these properties on every access instead of
  caching them.
- GraphCast and MeshGraphNet run on graphs partitioned across GPUs again
  (`partition_size > 1`, or a `DistributedGraph` in place of the PyG graph),
  so the distributed shallow-water example works. This broke when the DGL
  backend was removed.
- `partition_graph_with_id_mapping`, and so `partition_graph_nodewise`,
  `partition_graph_by_coordinate_bbox` and `DistributedGraph`, accept `int32`
  CSC indices and rank mappings. Before, they failed with a dtype mismatch.
- `weighted_multinomial` with `replacement=True` accepts more than 2^24
  weights, instead of raising `torch.multinomial`'s category-limit error. So
  DoMINO's `sample_points_on_mesh` now works on meshes with over 2^24 faces.
- `MeshDataset.close()` no longer raises `AttributeError` with a `MeshReader`
  or `DomainMeshReader`. Both readers now have a `close()` method.
- `GLOBE` accepts `boundary_meshes` as a TensorDict, as the DrivAerML example
  passes them. Before, every forward pass of that example failed.
- A `GLOBE` model built with a `torch.device` as `tree_build_device` can now be
  saved. Before, `save()` raised `TypeError`, because JSON cannot hold a device.
- Under `torch.compile`, GLOBE no longer recompiles on its second training
  step, nor for each new sample of a similar size. Each of these recompiles
  took minutes at DrivAerML sizes.
- The GLOBE examples' requirements no longer downgrade PyVista and Matplotlib
  below the versions PhysicsNeMo requires.
- `compute_stats.py` in the `diffusion_fwi` example no longer overstates the
  mean and std of `vx` and `vz` in `stats.json`: their sums were not divided
  by the number of shots. The corrected statistics normalize those inputs
  differently, so a model trained with an older `stats.json` must keep using
  that file.
- `signed_distance_field`, in `physicsnemo.nn.functional` and
  `physicsnemo.mesh.spatial`, supports backpropagation: the signed distance is
  differentiable with respect to the mesh vertices and the query points.
  Before, `backward` raised because the Warp op had no autograd formula. The
  hit points and hit faces carry no gradients.
- With `max_points`, the Warp backend of `radius_search` leaves the `.grad` of
  batched points and queries unset in the forward pass. Before, it set them to
  zeros.
- `Mesh.clean()`, `clean_mesh`, `merge_duplicate_points`, and `validate()` find
  every duplicate point in clusters of more than 100 coincident points. Before,
  some duplicates were missed and stayed in the cleaned mesh.
- `Mesh.merge` treats a list of one mesh like a longer list. It checks its
  input and stacks `global_data` along a new dimension. Before, it returned a
  copy of the mesh.
- `Mesh.pad` and `Mesh.pad_to_next_power` place padding cells on a padding
  point when they also pad points. Before, padding cells touched the last real
  point and changed results there, such as `cell_data_to_point_data`.
- `DomainMesh.rotate`, `scale`, and `transform` work when the meshes of a
  domain differ in float dtype, such as a float64 interior with float32
  boundaries, where they raised before.
- `repair_mesh` also removes the degenerate cells that its merge of duplicate
  points creates. Before, its output could fail `validate()`.
- `fill_holes` works on meshes with point or cell data, where it raised before.
  The new points and faces hold NaN in floating-point fields and 0 in others.
- `compute_mesh_statistics` reports the mean and standard deviation of the
  edge lengths of all cells. Before, the mean averaged each cell's shortest and
  longest edge, and the standard deviation covered only the longest edges.
- `is_manifold()` rejects triangle surfaces pinched at a vertex, such as two
  closed surfaces that share a single vertex.
- `get_boundary_edges` returns edges, not triangles, for meshes of four or more
  manifold dimensions.
- `Mesh.with_data` given a dict no longer shares nested data groups with the
  source mesh, so changing the result leaves the source unchanged.
- `cell_data_to_point_data` and `point_data_to_cell_data` raise, unless
  `overwrite_keys=True`, when a field has the name of a data group in the
  destination or the reverse. Before, they silently dropped data.
- Cleaning or repairing a mesh with no cells keeps its point data fields, now
  empty, so the result can be merged with other meshes.
- `get_point_to_points_adjacency()` returns no neighbors for meshes of vertex
  cells, where it raised before.
- `Mesh` and `DomainMesh` subclasses that add fields no longer need their own
  `__init__` with TensorDict 0.15, whose tensorclass subclasses inherit the
  parent's `__init__`. The base `__init__` accepts and stores the fields that a
  subclass declares, and still raises `TypeError` for any other keyword.
- Linear subdivision of tetrahedral meshes keeps the orientation of every
  child cell. Before, half of the children came out inverted.
- The `unit_square`, `rectangle`, `structured_grid`, `l_shape`, `cube_volume`,
  `torus`, `hemisphere`, `disk`, `plane` and `tetbeam` primitives have
  positively oriented cells and outward or +z normals. Before, their cells were
  inverted or their normals pointed the wrong way. `plane` also raises
  `ValueError` for a zero or non-finite normal, where it used to return the +z
  plane.
- Meshes with `int32` connectivity give the same results as `int64` ones in
  Butterfly and Loop subdivision, edge lookups and `refit_mesh_to_implicit`.
  Before, large meshes could get wrong Butterfly midpoints and edge matches,
  Loop subdivision raised on open surfaces, and `refit_mesh_to_implicit` could
  leave boundary vertices off the surface.
- Loop subdivision of `float64` meshes computes its vertex weights in
  `float64`. Before, it computed them in `float32`, which limited the new
  vertex positions to `float32` precision.
- A mesh saved with cached adjacencies now loads in a new Python process.
  Before, `Mesh.load` raised unless `physicsnemo.mesh.neighbors` was already
  imported.
- Intrinsic cell gradients on curves in 3D now lie along each cell's own
  direction. Before, they crashed on open curves and were projected onto the
  wrong tangent on closed curves.
- Intrinsic point gradients on manifold meshes no longer depend on the winding
  of the cells, at any angle between them, so they are correct on
  `get_boundary_mesh` output and on the Möbius strip. Consistently wound meshes
  give the same results as before.
- Curvature of a curve whose two edges at a vertex both start or both end
  there, as `get_boundary_mesh` produces, is now correct. Before, the angle at
  such a vertex was wrong, so a right-angled corner had zero curvature.
- DEC gradients, divergences, and Laplacians of a float32 field on a float64
  mesh now return float64 results instead of raising. DEC gradients and
  Laplacians of tensor fields, and LSQ cell gradients, no longer fail on meshes
  without cells, and `flat` handles fields with several trailing dimensions.
- Intrinsic LSQ gradients no longer raise on float32 point clouds or on 16-bit
  curves, and raise a `TypeError` for integer fields instead of truncating the
  result. On surfaces in four or more dimensions they are now correct at points
  with two neighbors, and DEC intrinsic gradients of curves in 3D are now
  correct at their endpoints.
- Derivatives of intrinsic gradients with respect to the points are no longer
  NaN on straight curves in 3D, or flat surfaces in 4D, that lie along the axes.
  On curves in 3D and surfaces in 4D, only first derivatives are exact.
- DEC gradients of planar triangle meshes are no longer NaN at the vertices of
  zero-area triangles, such as those `Mesh.pad` adds. DEC divergences are now
  correct on float32 meshes a few millimetres across in metres.
- `Mesh.clean` now sums the point measures of merged points, so integrals by
  point quadrature no longer change.
- `DefaultCollator` with a `stack_dim` past the batch dimensions of the
  samples stacks each tensor with `torch.stack`, without TensorDict behaviour
  that 0.15 deprecates. The batch's `batch_size` now matches its tensors, and
  samples with non-tensor data no longer fail to collate.
- `physicsnemo.mesh` no longer raises small lengths, areas and volumes to a
  fixed floor, which distorted results on float32 meshes in meters a few
  millimeters across. Area-weighted aggregation, `partition_cells` centroids,
  support volumes, the DEC Laplacian, the sharp, Gaussian, and mean curvatures,
  and triangle circumcenters now give the same results at any scale.
- `sample_random_points_on_cells` with a small `alpha` no longer places some
  points outside their cells.
- In float32, `sdf_polygon_2d` no longer gives NaN distances for a polygon
  with a repeated vertex or NaN gradients on its edges, and
  `mesh_implicit_domain` now meshes float32 polygons such as a square.
- The API reference again shows the docstrings of `Mesh`, `DomainMesh`, and the
  other tensorclasses in `physicsnemo.mesh`. TensorDict 0.14 replaced them
  with generated signatures.
- Meshes with explicit measures integrate correctly after `get_facet_mesh`,
  `get_boundary_mesh`, `to_edge_graph`, `extrude`, `project`, `embed` and `pad`.
  Before, facets and extruded cells inherited the parent's measure, `project`
  kept the old one, `embed` raised on centroid point clouds, and padding cells
  got NaN measures that made a later `scale` raise. `extrude` now raises on
  dimensional point measures instead of copying them to the extruded points.
- `DomainMesh.apply_to_meshes` leaves each boundary mesh on the device the
  function returns it on. Before, the boundaries went back to the domain's
  device.
- `rotate` with a Python angle rotates float64 meshes at float64 precision.
  Before, it computed the rotation in float32.
- `rotate` rotates float64 meshes about a vector axis at float64 precision.
  Before, it rounded the axis to float32, so points on the axis moved.
- `rotate`, `scale`, and `transform` with a square matrix work on float16 and
  bfloat16 meshes, and keep their dtype. Before, they raised an error.
- Loop subdivision keeps float16 and bfloat16 points in their dtype, and no
  longer overflows on float16 meshes far from the origin. Before, it returned
  float32 points.
- `cell_areas`, `cell_normals`, and Butterfly subdivision compute in at least
  float32 and cast back once, so float16 results that fit in float16 are
  finite. Before, their cross products, determinants, and sums of positions
  overflowed float16 to `inf` or `nan`, and `scale` gave finite areas only if
  they were cached before the call.
- `cell_areas` of n-simplices in n-space with n >= 4, such as 4-simplices in
  4D, take the determinant of the edge vectors directly. Before, the Gram
  determinant squared the condition number of the edge vectors, so nearly flat
  cells lost their float32 volume to cancellation.
- `sample_random_points_on_cells` with `alpha` other than 1 works on float16
  and bfloat16 meshes on CPU. Before, it raised an error.
- Anisotropic maps with a small overall scale are no longer taken for
  similarities. Before, transforming by one kept wrong cached point normals,
  and scaled point measures instead of raising.
- `pad_to_next_power` pads to the smallest power that fits. Before, a size that
  already was such a power could be padded to the next one, and some
  non-integer powers raised.
- The GLOBE examples no longer pin TensorDict 0.12, which conflicted with
  PhysicsNeMo's own requirement.
- `delaunay_mesh_2d` recovers boundary segments that cross several triangles.
  Before, it raised on simple polygons, even rectilinear ones, and blamed
  float64 degeneracy or crossing segments.
- `signed_distance_field` accepts non-contiguous query points and vertices,
  such as a transposed tensor, which used to raise a Warp error.
- The mesh `signed_distance_field` keeps the orientation of the near-degenerate
  faces it repairs. Before, the repair could flip a thin face, so points
  outside a watertight mesh got a negative distance.
- `knn` with the cuML backend, `find_nearest_cells` and `match_points` return
  empty results for an empty query set on CUDA, as they do on CPU, instead of
  raising a CUDA error. `match_points` also returns no matches for an empty
  target.
- Mesh transforms and projections keep the dtype of each vector and tensor
  field. A float32 field on float64 points, as VTK files often store them,
  raised a dtype error.
- The GLOBE AirfRANS example casts its meshes to float32. Since `from_pyvista`
  began keeping float64 points, preprocessing failed on every sample.
- `DomainMeshReader` gains `boundary_subsample` (`"both"`, `"cells"`,
  `"points"`) to choose which subsample applies to the in-file boundaries.
  Composing the cell and point subsamples on a triangulated boundary kept only
  the cells whose three vertices all survived the point cut, about `N / 27` of
  the `N` requested. The default keeps the composed behavior.
- The `hemisphere` and `cone` primitives have a single pole or apex vertex,
  so the cone is closed. Before, the vertex was repeated around the ring,
  leaving zero-area triangles.
- `tetrahedron_surface` edges have length `side_length`, and
  `sphere_icosahedral` with `subdivisions=0` honors `radius`.
- `sphere_volume` and `cylinder_volume` tetrahedra fill the solid without
  overlap. With VTK 9.7, their Delaunay tetrahedra overlapped and left gaps.
- `lumpy_ball` raises `ValueError` when `noise_amplitude` folds its surface
  so far that the tetrahedra would overlap.
- `text_1d_2d` outlines are closed loops; before, each ended in a zero-length
  edge. `text_2d_2d` fills curved glyphs fully: thin rings such as U+25CB lost
  part of their area.
- `text_2d_2d` fills glyphs with slanted edges, such as 'A' and 'V', without
  flat triangles or hanging vertices, so `text_2d_3d` of ordinary text is
  watertight. It also leaves the counter of a nested glyph empty: '®' was 3%
  too large.
- `cone`, `disk` and `plane` work when torch's default dtype is float64, where
  they raised before.
- Unified external aero recipe: GLOBE-volume trains on all the requested
  vehicle surface cells, not about 4% of them.
- Seeded `DomainMeshReader` subsamples select the same rows from Zarr stores
  as from memmap files. Before, boundaries read in full, and interiors read
  with `drop_interior_cells`, could differ between the two formats.
- `from_pyvista(point_source="cell_centroids")` places the centroid of every
  linear cell at the mean of its vertices, as `Mesh.cell_centroids` does.
  Before, polygons, pyramids, prisms and polyhedra got other points, and even
  a regular pentagon was off-center.
- `to_pyvista` exports vertex-cell meshes, and empty line and triangle meshes,
  with their cell data. Before, the export failed.
- `to_zarr` raises a `TypeError` naming any field it cannot store, such as a
  bfloat16 field, before it writes anything. Before, it left a partial store
  that loaded without those fields.
- `to_zarr` raises a `ValueError` before it writes anything when a field key
  or boundary name is one that zarr cannot store, such as one that is empty or
  contains `/`. Before, such a name could come back as another key, or leave a
  store that would not load.
- `from_zarr` loads the stores that `to_zarr` writes for subclasses of `Mesh`
  and `DomainMesh`, as their base class, and `to_zarr` raises a `TypeError` on
  a subclass with fields of its own. Before, `from_zarr` refused these stores.
- `from_zarr`, `MeshReader` and `DomainMeshReader` keep the cell shape of a
  zarr mesh with zero cells. Before, such a mesh came back as a point cloud.
- With domain-parallel reading, `MeshReader` and `DomainMeshReader` also keep
  the cell shape and cell data of a mesh with zero cells. Before, such a mesh
  came back as a point cloud, so computing its normals or merging it with
  other boundaries raised.
- `to_pyvista` exports empty meshes with vector or tensor fields, where it
  raised before, and `from_pyvista` reads complex arrays of one value with
  shape `(1,)`, where it raised or dropped a dimension before.
- `from_pyvista` with `point_source="cell_centroids"` joins two cells of
  different dimensions by the same dual-graph edges whatever the order of the
  cells. Before, these edges depended on it.
- `from_zarr`, `MeshReader` and `DomainMeshReader` raise on a zarr store that
  `to_zarr` did not write or did not finish. Before, a store cut short by a
  full disk, for example, loaded without its missing fields.
- `from_zarr` loads scalar uint64 fields, where it raised before.
- `Mesh.draw` with matplotlib colors 2D curves by their scalars and honors
  `alpha_edges`. It also draws 1D meshes in view, vertex cells as colored
  markers, and integer vector scalars, where it failed before.
- `Mesh.draw` with matplotlib fits the view to every mesh drawn on `ax` and,
  in 2D, keeps limits the caller fixed; before, it showed only the last mesh.
  Meshes far from the origin no longer shrink to a speck in the view.
- `Mesh.draw` with PyVista lets `backend_options` set the edge color, line
  width and scalar bar, where it raised before.
- GLOBE DrivAerML postprocessing reports correct Cd, Cl, and Cs on subsampled
  surfaces. Before, they shrank with the fraction of cells kept.
- The unified external aero recipe documents how surface subsampling affects
  force integration.
- `ClusterTree.find_dual_interaction_pairs` returned an empty plan if any point
  had a NaN coordinate, and failed on plans with more than 2^31 interactions.
- `ClusterTree.from_points` no longer keeps the autograd graph of its inputs.
- With `expand_far_targets=True` and `leaf_size > 1`,
  `ClusterTree.find_dual_interaction_pairs` still approximated some targets by
  their leaf's centroid.
- Unified external aero recipe: the final epoch is always checkpointed,
  resumed runs keep the epoch-mode learning-rate schedule (older checkpoints
  resume one epoch behind), and fp16 runs save and restore `GradScaler` state.
- Checkpoint loading resolves model weights at the selected training checkpoint's
  filename index, preventing resumes that mix epochs. Missing required weights
  raise before any model or training state is restored. Distributed loads validate
  on every rank using rank 0's file lookup.
- `fix_orientation` no longer leaves opposite windings across sharp creases,
  such as the edges of a cube.
- `Mesh.is_manifold()` no longer raises on a tetrahedral mesh with a
  degenerate cell.
- Mesh slicing reuses integer indices across connectivity, fields, and caches
  to avoid repeated CUDA synchronization for the same boolean mask.
  Point slicing skips mask processing when the output has no cells because
  the input has no cells or the point selection is empty.
- DEC gradients (`gradient(method="dec")`) of tetrahedral meshes read triangle
  faces as edges and were wrong at most vertices, and on 1D meshes they raised.
  They now use the edges of every cell and are exact for linear fields on
  segments, triangles and tetrahedra. `to_edge_graph()` works on 1D meshes, and
  `get_facet_mesh(manifold_codimension=0)` returns the deduplicated cells.
- Meshes from `slice_cells` and `subdivide` get their own data containers, so
  adding or removing a field on them no longer changes the source mesh.
- Triangle areas use direct area components and a rescaled norm, preserving
  thin faces and their quadrature measures without Gram cancellation or
  overflow or underflow in the norm.
- Vertex angles of nearly flat triangles in 2D and nearly flat tetrahedra are
  now accurate. A 2D triangle with an angle near pi used to get angles of 0, 0,
  and 0, which also threw off Gaussian curvature and quality metrics.
- Gaussian curvature of curves in 3D is now correct: a unit circle with 1,000
  segments had a curvature of 499 instead of 1.
- Small angles from `stable_angle_between_vectors`, volumes of thin
  tetrahedra in 4D or more, and FEM cotangent weights of thin cells keep their
  accuracy in float32. The first two used to come out as 0.
- Mesh dual volumes of thin triangles, and the DEC operators and curvatures
  that use them, are accurate in float32. Before, the dual volumes of a mesh of
  thin triangles could sum to 2.4 times its area.
- FEM cotangent weights of long, thin but well-shaped cells are accurate in
  any vertex order. A tetrahedron with one edge 5,000 times longer than the
  others used to get the weights of a degenerate cell.
- Vertex angles of triangles in 3D are correct in float16 and at any
  coordinate scale, and `stable_angle_between_vectors` is correct in float16.
  Both used to return NaN or wrong angles there.
- On CUDA, LSQ gradients of rank-deficient stencils, such as those of a flat
  surface, are now minimum-norm solutions, as on CPU. They used to be NaN,
  wrong by orders of magnitude, or a `LinAlgError`.
- On CUDA, `sample_data_at_points` next to a degenerate cell no longer raises
  `LinAlgError`. Degenerate cells contain no sample points on any device, and
  `compute_circumcenters` returns their centroid instead of NaN or infinity.
- Edge flips in `mesh_implicit_domain` work at any coordinate scale; below
  about 1e-13 they were silently skipped.
- The PyTorch Sobolev deformation accepts float32 cells of any size, and the
  StVK strain energy has finite gradients for degenerate reference cells.
- Unified external aero recipe: near-wall SDF normals no longer flip inward
  from float32 roundoff. Stored signed distances are unchanged.
- Fixes mesh dtype handling: preserves integer-coordinate precision, normalizes
  connectivity safely, and rejects integer `.to()` casts. Floating-point and
  complex casts preserve the source mesh.
- Fixed an issue in `Natten2DSelfAttention` and `RopeNatten2DSelfAttention`
  with `qk_norm=True` mixing `LayerNorm` fp32 Q/K outputs with autocasted V
  dtypes.
- Normalizes cell, point, transformed, and partition-cluster mesh normals
  robustly across floating-point dtypes and scales. Zero vectors remain zero,
  small nonzero vectors retain unit length, and large finite vectors avoid
  norm overflow.
- Datapipe transforms, collators, readers, and the unified external aero
  recipe no longer silently skip or mis-handle nested `TensorDict` fields
  (membership was tested against top-level `td.keys()`, and
  `NormalizeMeshFields.inverse_td` matched leaves by their last name only).
- `from_pyvista` and `to_pyvista` round-trip nested `Mesh` data keys, and GLOBE
  accepts a nested `global_data_ranks` declaration.
- Fixes out-of-bounds reads in the `Darcy2D` multi-grid solver for
  `nr_multigrids >= 3` that could return huge or NaN pressure fields, and
  corrects the coarse-node coordinates used by bilinear upsampling for
  reduction factors greater than 2.
- `Darcy2D` permeability fields are random per sample again: the
  `init_uniform_random_4d` and `init_uniform_random_2d` kernels seeded every
  thread from only its first launch index, so all samples in a batch shared
  four random Fourier coefficients
  ([#2035](https://github.com/NVIDIA/physicsnemo/issues/2035)).
  `init_uniform_random_2d` also negated `min_value`, which made the
  `KelvinHelmholtz2D` perturbations constant.
- `Darcy2D` solves the Darcy equation it documents: the Jacobi update divided
  the `grad(k) . grad(u)` term by `2 dx` instead of `4 dx**2`, effectively
  dropping it ([#2036](https://github.com/NVIDIA/physicsnemo/issues/2036)).
  Generated pressure fields change; the `darcy` normaliser in the `darcy_fno`,
  `darcy_transolver` and `darcy_nested_fnos` examples is updated to match, and
  `darcy_nested_fnos` datasets must be regenerated.
- The `Darcy2D` convergence check no longer reports a diverged (NaN) solve as
  converged.
- `Module.save` now writes `.mdlus` checkpoints atomically (transfer to a
  temporary sibling name, then rename into place), so a process killed
  mid-write no longer leaves an unloadable truncated checkpoint. Also fixes
  `legacy_format=True`, which failed with `FileNotFoundError` on current
  fsspec versions.
- `save_checkpoint` now also writes training state and plain PyTorch weights
  atomically, so an interrupted save no longer leaves a truncated checkpoint.
  With `epoch=None`, all files of a save share one index, so `load_checkpoint`
  restores weights and training state from the same save.
- `RandomRotateMesh` defaults to `mode="axis_aligned"` when `axes` is given.
  Unified external aero recipe translation configs pass tensor bounds so
  `torch.distributions.Uniform` instantiates.
- `RenameMeshFields` and `DropMeshFields` also apply to a `DomainMesh`'s
  domain-level `global_data`.
- `sample_data_at_points` and `find_containing_cells` find on-surface points
  of float32 surface meshes in large length units. A torus scaled to
  `|x| ~ 1300` (millimeters) previously found 0.4% of its on-surface points
  and returned NaN for the rest, because float32 rounding (about
  `1.2e-7 * |x|`) exceeded the absolute `1e-6` distance tolerance.
- `BVH.from_mesh` and `ClusterTree.from_points` compute Morton codes for 1-3
  spatial dimensions by spreading each coordinate's bits with a few
  shift-and-mask steps. CUDA no longer materializes every bit as int64 (about
  1 kB per point, 55 GB at 50M cells); temporaries are about 72 B per point in
  3D, and the step is about 4x faster on large inputs. Codes are unchanged.
- `sample_data_at_points`, `find_containing_cells`, and
  `find_all_containing_cells` no longer miss the containing cell when a query
  point has more than 32 BVH candidate cells (for example, near a vertex shared
  by many triangles, or with a prebuilt BVH with `leaf_size > 1`). The BVH
  candidate search used by these functions no longer caps candidates per point.
- Fixes `VPNoiseScheduler.sigma_inv` at extreme noise levels. In particular,
  converting `sigma=0` no longer returns a slightly negative diffusion time.
- `radius_search` with `implementation="torch"` no longer returns point 0's
  coordinates in unused neighbor slots when `max_points` exceeds the number of
  points. Those slots now stay zero, as with the warp backend, so point 0 no
  longer receives their gradient.
- Eleven PhysicsNeMo-Mesh API pages that listed no functions now document them,
  and the pages of tensorclasses such as `Mesh` no longer list every TensorDict
  method.
- PhysicsNeMo-Mesh examples that raised an error, and claims that the code
  contradicts, are corrected across the API reference, READMEs, and docstrings.
  The corrected claims include the sign of the Laplacian and the dimensions
  that each calculus operator supports.
- The transient conjugate heat transfer tank filling example trains again, on
  one GPU or several. Before, its `train.py` stopped with a `TypeError` before
  the first step.
- The XAeroNet volume example's `compute_stats.py` starts again, and reads the
  training voxel grids from the `h5_path` of its config. Before, it stopped
  with an `ImportError`, and then looked for a `partitions_path` key that only
  the surface recipe's config has.
- The transient conjugate heat transfer tank filling example's `compute_stats`
  no longer leaves a file out of the volume minimum and maximum when that
  file's `surface_fields` array is empty.
- Importing `physicsnemo.domain_parallel` no longer breaks `torch.compile` for
  the whole process when nothing has imported `torch._dynamo` before it.
- `MeshReader` and `DomainMeshReader` implement `close()`, so
  `MeshDataset.close()` works on the mesh path.
- Coordinated subsampling in the zarr readers picks its reference key in the
  configured order rather than set order, so the rows read are deterministic.
- `ShardTensor` fixes for domain parallelism: redistribute no longer grows an
  unbounded planner cache for fixed shapes (step time was climbing with step
  count),
  `scatter_tensor` returns a shard that owns its storage, stream recording on
  wrapped tensors works, and several `torch.compile` tracing issues are
  resolved.
- `torch.unbind` on a `Partial` `ShardTensor` resolves the pending reduction
  before slicing instead of silently dropping it.
- Fixed autocasting bugs for some attention operations in domain parallelism.
- Backward through `ShardTensor.to_local()` adopts the gradient's shard order
  along with its placements, so a sharded primal with a replicated cotangent
  no longer trips a `DTensorSpec` assertion.

### Security

- CI and the Docker image no longer trust the compromised eMudhra emSign root
  CA ([advisory](https://discuss.python.org/t/109576)). uv is now 0.13.5 in
  CI and the Dockerfile, the image upgrades `ca-certificates` and requires
  `pip>=26.2.2` and `certifi>=2026.10.19`, and the lockfiles pin `certifi` 2026.10.23 and
  `virtualenv` 21.14.13. The GPU CI bootstrap installs the Hugging Face CLI
  with uv instead of Ubuntu's apt pip, and `install-ci` sets `check-latest`
  so it uses the patched CPython releases.

### Dependencies

- Requires TensorDict 0.15.3 or later (`tensordict[zarr]>=0.15.3,<0.16.0`).
  Building, copying, and moving small meshes takes 20-50% less time on CPU.
  TensorDict's `torch.compile` fixes since 0.15.0 also stop compiled code from
  recompiling when a `Mesh` holds the same fields in another order.
- Drops `onnx`, `torchvision` and `pandas` from the required dependencies.
  `pandas` is now optional via `datapipes-extras` or `model-extras`.

## [2.2.1] - 2026-XX-YY

### Fixed

- Allows installation on all Python 3.14 patch releases while continuing to
  exclude Python 3.15 and later.
- Pins install CI to the interpreter provisioned by `setup-python` and verifies
  the runtime version, preventing `uv` from silently selecting another Python.
- Keeps tensorclass mesh API annotations introspectable under Python 3.14's
  deferred annotation evaluation.

## [2.2.0] - 2026-08-27

### Added

- Adds `ShardTensor` support for GeoTransolver and FLARE models.
- Adds zarr save/load for `Mesh` and `DomainMesh` via tensordict's zarr
  storage backend: `physicsnemo.mesh.io.to_zarr` / `from_zarr`, with
  training-appropriate chunking and zstd compression. `MeshReader` and
  `DomainMeshReader` transparently read zarr stores alongside
  `.pmsh`/`.pdmsh` (opt in via `pattern`). Requires optional `zarr >= 3`
  and a tensordict release with the zarr backend.
- Adds configurable activation checkpointing to Transolver, FLARE, and
  GeoTransolver. Transolver and FLARE support interleaved block checkpointing;
  GeoTransolver supports checkpointing context construction, per-stream input
  projections, GALE or GALE_FA blocks, and output projections.
- Promotes GeoTransolver out of `experimental` to
  `physicsnemo.models.geotransolver.GeoTransolver`, together with the FLARE
  model (`physicsnemo.models.flare.FLARE`) and the reusable GALE and FLARE
  attention layers (`physicsnemo.nn.GALE`, `physicsnemo.nn.GALEBlock`,
  `physicsnemo.nn.FLARE`). The embedded OOD guard is decoupled from the model.
  Wrap a constructed GeoTransolver with
  `physicsnemo.experimental.guardrails.embedded.GuardedGeoTransolver` (or
  `attach_ood_guard`) to enable out-of-distribution guarding. PhysicsNeMo removes
  the  `guard_config` model argument. Legacy import shims keep the pre-move
  `physicsnemo.experimental` import paths working and emit a
  `LegacyFeatureWarning` pointing to the new locations.
- Adds `zenith_azimuth_angles` and `zenith_azimuth_angles_from_timestamp` to
  `physicsnemo.utils.zenith_angle`, returning
  `(sin_zenith, cos_zenith, sin_azimuth, cos_azimuth)` alongside the existing
  `cos_zenith_angle` / `cos_zenith_angle_from_timestamp` helpers. The azimuth
  follows the north-clockwise convention.
- Adds `physicsnemo.nn.shrink_and_perturb_`, an in-place shrink-and-perturb
  weight re-initialization for warm-starting from pretrained weights.
- Adds dimension-generic volume mesh generation for implicit domains to
  `physicsnemo.mesh.generate`. `mesh_implicit_domain` meshes
  `{x : phi(x) < 0}`, clipped to the bounding box (box faces are honored
  as a boundary, so that external-flow "box minus obstacle" domains work
  directly), for any implicit function (signed-distance functions, level
  sets, or neural fields).
- Adds compile-safe subclassing extension points to `domain_parallel.ShardTensor`
  (`_extra_inner_tensors`, `__subclass_flatten_context__` / `__subclass_unflatten__`,
  `_stable_inner_sentinel`, and a DTensor-style `__metadata_guard__`), so a subclass can
  carry extra inner tensors and opaque metadata through `torch.compile` without
  re-implementing the flatten protocol. Base behavior unchanged.
- Adds `ShardTensor._subclass_propagated_attrs`: attribute names base `__torch_function__`
  copies from an op input onto its eager op-result, re-classing it to the subclass. Skipped
  under compile; empty by default.
- Adds `install_aot_plain_tangent_coercion` (run on import): rebuilds a plain backward
  cotangent into a `ShardTensor` when a boundary crosses a Dynamo graph break, instead of
  AOTAutograd raising "guessed its metadata incorrectly". `__coerce_same_metadata_as_tangent__`
  now also coerces down to a plain tensor at a replicated boundary.
- Adds `domain_parallel.shard_utils.halo_scatter`: a `torch.compile`-safe halo
  scatter-correction primitive for `Shard(0)` ShardTensors with a borrowed-ghost overlay.
  `halo_scatter_correct` fuses the fold-to-owner / refresh-ghost exchanges into a self-adjoint
  `custom_op` (correct forward and backward under `aot_eager` and inductor), with routing
  passed as a packed graph-input tensor so it survives graph breaks;
  `register_halo_scatter_handlers` wires it onto `scatter_add` / `index_add`. The row
  transport is a pluggable backend (`select_halo_backend`, `PHYSICSNEMO_HALO_BACKEND`):
  a portable `funcol` path and an intra-node symmetric-memory (CUDA-IPC) path.
- Extends `halo_scatter` with `pack_halo_routing(cap=)` fixed-shape routing (for compiled
  `dynamic=False` runs), an in-place `scatter_add_` / `index_add_` dispatch handler, and
  node-locality routing in `select_halo_backend` (single-node uses symm-mem, multi-node
  falls back to `funcol`).
- Adds a `ShardTensor.grad_dtype` property override (returns the local tensor's dtype)
  so a newer-PyTorch `grad_dtype` read during Dynamo fake conversion doesn't fall back
  to a non-leaf DTensor and break compile. Mirrors the `grad_fn` / `is_leaf` / `grad`
  shields.
- Adds `integrate_moment` and `Mesh.integrate_moment` for measure-weighted
  outer-product moments. Mesh integration APIs now accept `nan_policy`.
- Adds per-cell measure weights that are preserved through cell subsampling
  and consumed by mesh integration routines and GLOBE.
- Adds a `global_shape` argument to `ShardTensor.from_local`, enabling the
  no-communication `sharding_shapes="chunk"` path.
- Adds exact-boundary quality mesh generation to
  `physicsnemo.mesh.tessellation`: `fill_interior` takes a closed
  codimension-one boundary `Mesh` (2D edge loops today; loops in any order
  and orientation, with holes, multiple components, and nested islands
  resolved automatically) and fills the interior with quality simplices via
  constrained Delaunay triangulation with Ruppert refinement — every input
  vertex is preserved bit-identically, every output triangle meets the
  guaranteed minimum-angle bound, output is a `Mesh` with provenance
  `point_data`, deterministic, with optional bound-preserving ODT smoothing.
  The contract is dimension-generic; `n = 3` raises `NotImplementedError`
  pending exact boundary recovery. Also adds `polygon_interior_point`,
  which returns a point strictly inside a simple polygon.
- Adds `rectilinear_grid_divergence`, `rectilinear_grid_curl`, and
  `rectilinear_grid_laplacian` to `physicsnemo.nn.functional`, with Torch and
  fused Warp implementations for periodic, nonuniform rectilinear grids.
- Adds triangle-surface remeshing with NVIDIA Warp on CPU and CUDA, including
  `remesh`, `Mesh.remesh`, topology cleanup, barycentric point-data transfer,
  direct or attached linear-resolution-field control, and advanced tensor-level
  tuning.
- Adds coverage reporting on PRs — an informational `Coverage %` check plus a
  ready-to-enable Codecov integration.
- Adds differentiable mesh morphing: Torch-backed dense ``displace_points`` /
  ``Mesh.displace`` and Torch/NVIDIA Warp compact sparse-control
  ``morph_points`` / ``Mesh.morph`` / ``DomainMesh.morph``.
- Adds differentiable Sobolev mesh deformation through
  `sobolev_deform_points` and `Mesh.sobolev_deform`. A matrix-free,
  uniform-mass P1 Helmholtz solve smooths dense per-vertex displacements and
  their adjoints, with optional fixed-point constraints. Torch and CUDA Warp
  backends provide explicit implicit-adjoint differentiation.
- Adds thin-plate-spline radial-basis deformation through
  `radial_basis_function_deform_points`,
  `Mesh.radial_basis_function_deform`, and
  `DomainMesh.radial_basis_function_deform`. PyTorch performs the differentiable
  coefficient solve. Torch and fused NVIDIA Warp backends evaluate the field.
- Adds differentiable lattice free-form deformation with Torch and NVIDIA Warp
  backends: dimension-generic ``free_form_deform_points`` /
  ``Mesh.free_form_deform`` / ``DomainMesh.free_form_deform`` with Bernstein
  (classic FFD) and locally supported uniform cubic B-spline bases, plus
  node-interpolating `linear`, `cubic_hermite`, and `quintic_hermite` modes.
- Adds fixed-topology ``simplex_strain_energy``, ``simplex_measure_energy``,
  ``total_measure_energy``, ``simplex_inversion_energy``,
  ``closed_surface_volume_energy``, and ``surface_bending_energy`` to
  ``physicsnemo.nn.functional``, with mesh-aware wrappers in
  ``physicsnemo.mesh.deformation``. Torch supports higher-order derivatives,
  and Warp provides first-order GPU kernels.
- Adds differentiable nearest-surface shrinkwrap through
  `shrinkwrap_points` and `Mesh.shrinkwrap`. Torch provides the reference
  search, NVIDIA Warp accelerates ``float32`` nearest-face queries on CPU and
  CUDA. Both backends replay the selected projection with PyTorch autograd.
  Triangulated examples demonstrate weighted panel conformance and partial
  design-region projection onto a shape-optimization constraint.
- Adds `uniform_grid_divergence`, `uniform_grid_curl`, and
  `uniform_grid_laplacian` to `physicsnemo.nn.functional`, with Torch and fused
  Warp implementations for periodic Cartesian grids.
- Adds the experimental Strata weather-emulation models —
  `physicsnemo.experimental.models.strata.Strata` and `StrataTransformer3D` — plus
  the continuous / stereographic RoPE helpers `build_rope_cos_sin_1d_continuous`,
  `build_axial_rope_cos_sin_2d_continuous`, `stereographic_projection`, and
  `spherical_centroid` in `physicsnemo.experimental.nn`.
- Adds Point-Transformer local vector-attention blocks to `physicsnemo.nn`.
- Adds an `is_causal` option to `TimmSelfAttention` in `physicsnemo.nn` for
  causal self-attention.
- FSDP2 checkpoint support: full save/load round-trip for
  ``torch.distributed.fsdp`` v2 models, including DTensor edge cases,
  cross-mesh reloads, and optimizer state loading.
- Migrated the StormCast example from DDP + Domain Parallel  to FSDP2 +
  Domain Parallel. StormCast previously used ``FullyShardedDataParallel``
  with ``ShardingStrategy.NO_SHARD`` (equivalent to DDP) alongside domain
  parallelism; it now uses the FSDP2 ``fully_shard`` API, producing 2D-mesh
  DTensor parameters when ``use_shard_tensor`` is enabled.
- Adds tensor-returning `Mesh.gradient`, `Mesh.divergence`, `Mesh.curl`, and
  `Mesh.laplacian` convenience methods to `physicsnemo.mesh`, mirroring
  `Mesh.integrate` (each returns a tensor and accepts a data key or a raw
  tensor, with a `data_source="points"|"cells"` kwarg selecting vertex or
  cell-centered fields). This gives the discrete differential operators a
  consistent, discoverable surface on `Mesh`; previously divergence/curl/
  laplacian were reachable only as free functions in `physicsnemo.mesh.calculus`.
  Adds `compute_divergence_cells_lsq` and `compute_curl_cells_lsq` free
  functions (cell-centered LSQ analogues); DEC operators and the cotangent
  Laplacian remain vertex-only and raise `NotImplementedError` for cell data.
- Adds `farthest_point_sampling` to `physicsnemo.nn.functional`, a greedy
  farthest-point sampling (FPS) functional for point clouds.
- Adds `FourierPositionalEmbedding` to `physicsnemo.nn`, a deterministic
  axis-wise (NeRF-style) Fourier positional embedding for continuous
  coordinates with no learnable parameters.
- Adds radiation transport example (`examples/nuclear_engineering/radiation_transport`)
- Adds agent skills structure, and initial skill for 'discoverability'.
- Adds the experimental AeroJEPA model
  (`physicsnemo.experimental.models.aerojepa.AeroJEPA`), a joint-embedding
  predictive architecture for 3D aerodynamic fields composing context and
  target encoders, a query-token field decoder, and a JEPA predictor head,
  together with its SIGReg, token-latent, and reconstruction loss family.
  The generic point-cloud tokenizer and the batch/mask/k-NN helpers are added
  under `physicsnemo.experimental.nn`; the local point-transformer attention
  blocks it composes come from `physicsnemo.nn`.
- Adds the AeroJEPA SuperWing tutorial recipe
  (`examples/cfd/external_aerodynamics/aerojepa`), an end-to-end Hydra-driven
  workflow covering dataset download, normalization, JEPA training, chunked
  inference, field-error plots, and CL/CD post-processing.
- Adds xDeepONet to experimental models
  (`physicsnemo.experimental.models.xdeeponet.DeepONet`).  A single
  dimension-generic (2D/3D) DeepONet that accepts a spatial or MLP branch,
  an optional trunk, and an optional second branch as `nn.Module` inputs
  (dependency injection).  Six forward-call conventions cover trunked,
  trunkless, packed/auto-padded, and xFNO-style time-axis-extend modes.
  Supports multi-channel output, multiple decoder types (MLP, Conv,
  temporal projection), composable Fourier / UNet / Conv spatial branches
  (`SpatialBranch`), and coordinate features.
- Adds `FNO4DWrapper` to the xdeeponet package: a thin wrapper around the
  library `physicsnemo.models.fno.FNO` (`dimension=4`) that adds
  autoregressive time-axis extension over `(B, X, Y, Z, T, C)` inputs (predict
  a `K`-step forecast horizon via `target_times`).  Use
  `physicsnemo.models.fno.FNO(dimension=4)` directly when the time-axis
  extension is not needed.  3D FNO / Conv-FNO / U-FNO operators are expressed
  as `DeepONet(trunk=None, dimension=3)` with a Fourier/UNet/Conv
  `SpatialBranch`.
- Adds `Sin` elementwise sine activation to `physicsnemo.nn`, registered
  in `ACT2FN` so it can be looked up by name (`get_activation("sin")`).
- Adds active-learning recipe for external-aerodynamics surrogates
  (`examples/cfd/external_aerodynamics/active_learning_aero/`). Iteratively
  fine-tunes a GP-augmented GeoTransolver onto an out-of-distribution
  target class by scoring unlabeled candidates with a joint UQ signal
  (GP-vs-integrated-drag disagreement + GP posterior std) and selecting
  the top-`k` per round. Built on the `physicsnemo.active_learning`
  protocols and `physicsnemo.experimental.uq.VariationalGPHead`, with a
  layered structure (generic AL driver / GP-UQ recipe / aero adapter)
  designed for reuse on other UQ-based regression problems.
- Adds `FieldVariationalGPHead` to `physicsnemo.experimental.uq`, a pointwise
  independent multitask variational GP head for per-point, multi-channel *field*
  uncertainty. It is the field sibling of `VariationalGPHead` (which pools a
  geometry to one embedding and predicts a scalar): it keeps the point dimension
  and returns one Gaussian posterior per point per channel, so a single forward
  pass yields the field prediction, the total predictive variance and the
  epistemic-only variance — no ensembling or MC-Dropout. Backbone-agnostic (it
  consumes only a `(..., input_dim)` feature tensor), with an optional DKL MLP,
  a Matérn ARD kernel (5/2 by default), float64 GP internals, an `l2_radial` feature
  normalization that preserves the radial out-of-distribution cue, and an
  optional heteroscedastic observation-noise MLP. Includes a surface field-GP
  training recipe for GeoTransolver
  (`examples/cfd/external_aerodynamics/transformer_models/src/train_field_gp.py`).
- Adds a `return_point_features` forward flag to
  `physicsnemo.models.geotransolver.GeoTransolver`, which additionally returns
  the per-point latents computed just before the output projection. These are
  the features a pointwise head such as `FieldVariationalGPHead` consumes.
- Adds `LatentNoveltyQueryStrategy` to the active-learning aero recipe,
  a third acquisition strategy that ranks unlabeled samples by their
  average kNN cosine distance in the encoder's learned geometry latent
  — reusing the same `OODGuard`
  (`physicsnemo.experimental.guardrails.embedded`) that flags
  out-of-distribution inputs at inference time. The guard is calibrated
  on the currently labeled set each round; round 1 falls back to
  class-balanced random because the calibration buffer is empty. New
  public `OODGuard.score_geometry()` method exposes the raw per-sample
  geometry-latent kNN distance as a continuous score for downstream
  consumers (e.g. AL acquisition) without the boolean thresholding /
  warning emission of `OODGuard.check()`.
- Adds rotary position embedding (RoPE) modules to `phyiscsnemo.nn` and
  integrates support for 2D RoPE in the neighborhood attention backend
  of `DiT` layers.
- Adds support for RoPE, dynamic invalid-region masking, and a new
  `ConvDetokenizer` in `phyiscsnemo.models.DiT`. Invalid regions are supplied
  per forward call via the `invalid_mask` argument of `DiT.forward` (a
  per-sample, batch-variable pixel mask, domain-parallel safe), replacing
  flagged tokens with a learned mask token.
- Adds an inference script (`src/infer.py` + `conf/infer.yaml`) to the
  Unified External Aero Recipe
  (`examples/cfd/external_aerodynamics/unified_external_aero_recipe`),
  with integrated aerodynamic force/moment coefficients (`src/forces.py`:
  CD/CL/CS/CMR/CMP/CMY). The script is model/dataset-agnostic, writes one
  native `.pdmsh` `DomainMesh` per sample (carrying physical-unit
  `pred_<field>` / `true_<field>`), reports training-space metrics
  (matching the training/validation loop), and reuses the trainer's
  dataloader / collate / metric tooling (refactored into `datasets.py`
  and `utils.py`).
- Adds `physicsnemo.mesh.spatial.signed_distance_field`, a `Mesh`-typed
  wrapper over the Warp-backed `physicsnemo.nn.functional.signed_distance_field`
  op (CPU and CUDA), returning `(sdf, hit_points, hit_faces)` per query. The
  sign comes from Warp's angle-weighted pseudo-normal (robust at
  sharp/non-convex edges) or, with `use_sign_winding_number=True`, its
  generalized winding number (robust on non-watertight meshes).
  (Near-)degenerate faces, which the Warp mesh query would otherwise skip,
  are repaired into equivalent thin-but-valid triangles before the query.
  Supersedes and removes the private datapipes implementation
  (`physicsnemo.datapipes.transforms._sdf_torch` / `_sdf_triton`); the public
  datapipes SDF transform delegates here.
- Added an iterable style dataset to physicsnemo datapipes, for on-the-fly gpu simulations.
- DPS guidance now supports **non-uniform guidance strength**: the `std_y` and
  `gamma` arguments of `physicsnemo.diffusion.guidance.ModelConsistencyDPSGuidance`
  / `DataConsistencyDPSGuidance` and their
  `physicsnemo.diffusion.multi_diffusion` counterparts accept tensors as well as
  floats. A tensor assigns a different measurement-noise level / SDA scaling to
  each observation component, e.g. per-channel (`(1, C, 1, 1)`) or pointwise
  (full observation shape). Passing floats keeps the previous uniform
  behavior unchanged.
- Adds `relative_mse` and `relative_l2` (target-normalized regression errors,
  `relative_l2 = sqrt(relative_mse)`) to `physicsnemo.metrics.general`
  (`relative_error.py`), with optional element `weights` and `dim`-based
  reduction matching `general.mse`.
- `physicsnemo.metrics.general.mse` `mse`/`rmse` gain an optional `weights`
  argument for a masked/weighted mean (backward-compatible; `weights=None`
  reproduces the prior unweighted result).
- Adds a kinetic Monte Carlo (KMC) surrogate example
  (`examples/kinetic_monte_carlo`): a probabilistic autoregressive surrogate
  (`ParticleGeoTransolver`) that emulates a KMC event stream, predicting the
  next event (the new particle's features and inter-event delay) from the
  current particle population, an optional background mesh, and the simulation
  time. Independent rollouts form an ensemble for uncertainty quantification.
- Adds an FP-DDM domain-decomposition example (`examples/tcad/fp_ddm`): an
  overlapping Schwarz method for steady 2-D thermal problems with a
  physics-informed PhysicsNeMo FNO local solver, a matrix-free finite-volume
  reference solver, and a numerical plane-stress elasticity baseline.

### Changed

- Splits the monolithic `physicsnemo.diffusion.noise_schedulers.noise_schedulers`
  and `physicsnemo.diffusion.samplers.solvers` modules into one module per class,
  named after the schedule or solver it defines, with the `NoiseScheduler` and
  `Solver` protocols in a `base.py` of their respective sub-package.
  Implementations are unchanged and every class is still re-exported from
  `physicsnemo.diffusion.noise_schedulers` and `physicsnemo.diffusion.samplers`,
  so the public import paths stay the same. The two old module paths remain as
  deprecated shims that re-export the same classes and raise a
  `DeprecationWarning` on import, so existing code keeps working. Import from
  `physicsnemo.diffusion.noise_schedulers` and `physicsnemo.diffusion.samplers`
  instead.
- `physicsnemo.nn.functional.signed_distance_field` now returns a 3-tuple
  `(sdf, hit_points, hit_faces)` — `hit_faces` is the int64 index of the
  triangle holding each closest point. Queries with no triangle within
  `max_dist` now return `NaN` distance/hit point and a `-1` face index
  (previously the out-of-band results were undefined: the kernel read from
  an uninitialized face index). Mesh-index range validation on CUDA inputs is
  now a device-side assert instead of a host-synchronizing check, so the op
  is safe on a sync-free prefetch stream; the eager `ValueError` is kept on
  CPU.
- Optimizes the production container build by consolidating related filesystem
  operations, using BuildKit bind and cache mounts, and separating custom,
  declared, and project dependency installation. Reduces total physicsnemo layers
  by around 78%.
- `GeoTransolver.forward`'s `return_embedding_states` and `return_point_features`
  are now keyword-only. They share a return signature, so a positional `True` did
  not say which was meant. Callers already passing them by keyword are unaffected.
- `ShardTensor.redistribute` now computes receive shapes analytically when
  sharding shapes are known, skipping the shape-negotiation `all_to_all`
  collective (falls back to the collective only when shapes are unavailable).
- PhysicsNeMo-Mesh tensor-valued gradients now consistently use the documented
  derivative-first layout `(entity, spatial_dimension, *value_shape)` across
  LSQ, intrinsic LSQ, and DEC. Earlier LSQ releases returned
  `(entity, *value_shape, spatial_dimension)` instead; migrate a stored legacy
  gradient with `legacy_gradient.movedim(-1, 1)`. Divergence and curl values
  are unchanged.
- xDeepONet `SpatialBranch`
  (`physicsnemo.experimental.models.xdeeponet.SpatialBranch`) now supports
  mixed-precision (AMP/autocast) training: FFT-based spectral convolutions are
  evaluated in float32 internally (cuFFT lacks complex-half support) while the
  rest of the branch uses autocast. This is a no-op under full precision, so
  fp32 outputs are unchanged. Also fixes a stale module docstring that
  referenced removed trunk/MLP-branch builder helpers.
- `physicsnemo.mesh.remeshing.remesh` now raises `NotImplementedError` for
  non-2D-in-3D inputs (the remeshing implementation is surface-only) instead
  of failing confusingly downstream, and its docstring reflects that
  restriction.
- `physicsnemo.mesh.spatial`: `BVH.from_mesh` and `ClusterTree.from_points` now
  share a single morton-LBVH node-topology builder (`spatial/_lbvh.py`),
  removing ~80 lines of duplicated build logic; construction output is
  byte-identical. `BVH.from_mesh` now defaults to `leaf_size=1` (was 8),
  matching `ClusterTree.from_points` and measured to be more performant across
  platforms (smaller leaves yield fewer candidate cells per query). Containment /
  nearest-cell query results are unchanged. Adds the first direct unit tests for
  `ClusterTree` (construction invariants, aggregates, dual-tree cover).
- `physicsnemo.mesh` performance: eliminated host-device syncs on hot paths.
  Cached topological adjacencies now store the `Adjacency` object directly instead
  of reconstructing it (which re-ran its syncing `__post_init__` validation) on every
  lookup — making cached adjacency lookups ~120x faster on GPU (~335us → ~3us for a
  10k-point sphere); the BVH leaf-hit expansion drops two per-traversal-level syncs;
  and the Laplacian smoother reuses its per-iteration buffers in place instead of
  reallocating them.
- `physicsnemo.mesh.Mesh.slice_cells` now accepts `None`/`Ellipsis` (keep all
  cells, return self), matching its type hint and `slice_points`;
  `gaussian_curvature_cells` reuses the cached `gaussian_curvature_vertices`
  property instead of recomputing it.
- `physicsnemo.mesh.Mesh` convenience methods now directly reuse shared
  canonical functions, removing duplicate implementation bodies and docstrings.
  This includes geometric, deformation (including radial-basis-function
  deformation), calculus, topology, visualization, and validation operations.
- `physicsnemo.mesh`: `draw` and `validate` are now the canonical standalone
  names matching `Mesh.draw` and `Mesh.validate`. The `draw_mesh` and
  `validate_mesh` remain as pending-deprecation compatibility names.
  `Mesh.validate` and `DomainMesh.validate` share the canonical validation
  option order, preserve the historical positional `tolerance` argument, and
  expose the new `check_self_intersection` option as keyword-only.
- `physicsnemo.mesh`: `validate(check_self_intersection=True)` now raises
  `NotImplementedError` (the check is unimplemented) instead of silently returning a
  `None` sentinel that masquerades as "no self-intersections found".
- `Mesh.strip_caches` and `DomainMesh.strip_caches` now accept a `keep`
  argument for retaining selected cache entries while clearing the rest.
  `Mesh.with_points` and `Mesh.with_cells` provide cache-aware coordinate and
  connectivity replacement for operations that preserve point or cell indexing,
  while data-only mesh transforms now preserve valid geometry and topology caches
  through `Mesh.with_data`.
- `physicsnemo.mesh` quality metrics now use a normalized
  aspect ratio of longest edge to minimum altitude. The metric is dimensionless and
  scale-invariant for simplices of every manifold dimension, and a regular
  simplex now has `aspect_ratio=1` and `quality_score=1`. This intentionally
  corrects the previous erroneous aspect-ratio and quality-score values.
- `Mesh.quality_metrics` and `Mesh.statistics` again use explicit property
  getters so their class-facing documentation describes argument-free property
  access. Configurable statistics tolerance remains available through the
  standalone `compute_mesh_statistics` function.
- Performance improvements in the diffusion module: reduced peak memory of
  DPS-guided diffusion sampling most notably for multi-diffusion at large
  domains. A guided `sample()` loop run under `torch.no_grad()` now detaches the
  state between solver steps, so the guidance autograd graph is no longer
  accumulated across the sampling trajectory (sampled outputs are unchanged;
  use `torch.no_grad()`, not `torch.inference_mode()`). Also expands CI test
  coverage and adds an API documentation page for
  `physicsnemo.diffusion.multi_diffusion`.
- Performance improvements in IO prefetching and GPU preprocessing in physicsnemo datapipes.
- &#9888;&#65039; **BC-impact (DPS guidance):** a custom `norm` callback passed to
  `physicsnemo.diffusion.guidance.ModelConsistencyDPSGuidance` /
  `DataConsistencyDPSGuidance` (and their `physicsnemo.diffusion.multi_diffusion`
  counterparts) must now return an **elementwise** loss (same shape as its
  inputs) instead of a per-batch-element reduced scalar of shape `(B,)`.
  Migration: drop the reduction from your `norm`, e.g. return
  `(y_pred - y_true).abs().pow(2)` rather than
  `(y_pred - y_true).pow(2).reshape(B, -1).sum(dim=1)`. For
  `DataConsistencyDPSGuidance` (and its `multi_diffusion` counterpart) the
  `norm` callback now also receives the **unmasked** `(x_0, y)` and the mask is
  applied to its output (`mask * norm(x_0, y)`), where it previously received
  the pre-masked `(mask * x_0, mask * y)`; the two agree for the built-in `Lp`
  norms, but a custom `norm` that relies on unobserved entries being zeroed
  before the call may differ. The integer `norm` selector (e.g. `norm=2`) is
  unaffected.
- `Mesh.transform` and `compute_cotan_weights_fem` now use the non-checking
  `torch.linalg.inv_ex` / `solve_ex` solvers, and build their index tensors on
  device. The checked solvers read a status code back to the host on every call,
  which synchronizes on CUDA; removing that and the index-tensor uploads takes
  `Mesh.transform` on a cached codimension-one mesh from three host
  synchronizations to one, and `compute_cotan_weights_fem` from six to three. As
  a consequence,
  `Mesh.transform(..., assume_invertible=True)` no longer raises when the matrix
  is in fact singular: it propagates NaN caches instead, as its docstring now
  documents. The default `assume_invertible=None` still tests the determinant
  and is unaffected.
- `physicsnemo.experimental.uq.VariationalGPHead` now takes `n_train` as a
  required keyword-only argument, along with every argument after `input_dim`.
  It was annotated optional while the constructor raised on `None`, so callers
  that already pass it by keyword are unaffected. It also gains `matern_nu`,
  which was previously hardcoded to 2.5 (still the default).

### Deprecated

- `physicsnemo.mesh.calculus.integrate_cell_data` and `integrate_point_data`
  are deprecated in favor of `integrate(..., data_source="cells"|"points")`.
  Compatibility wrappers remain available for this release and emit
  `LegacyFeatureWarning`.

### Removed

### Fixed

- `MeshReader` / `DomainMeshReader` sample discovery no longer uses
  `pathlib.Path.glob`, which can silently drop entries under filesystem
  metadata-server load (Lustre), causing training to proceed on a subset
  of the dataset.
- Unified external aerodynamics volume datasets now preserve in-file boundaries
  by default, so GLOBE can resolve `boundaries.vehicle` during collation.
  Point-based volume model templates explicitly opt into the existing
  boundary-dropping reader optimization.
- `compute_cotan_weights_fem`, and the calculus, curvature, and smoothing
  routines built on it such as `Mesh.laplacian`, no longer fail on degenerate
  cells in float32. The Gram-matrix regularization is now scale-free, so it also
  covers cells with no extent — including the null cells that `Mesh.pad` and
  `Mesh.pad_to_next_power` insert — and flat cells at large coordinate values,
  both of which previously raised a singular-matrix `_LinAlgError` from
  `torch.linalg.inv`. Weights for non-degenerate cells are unchanged bit for bit.
- Multinomial index sampling now uses one shared `weighted_multinomial`
  functional across datapipes, DoMINO, and remeshing. Its core API follows
  `torch.multinomial`, adds allocation-free integer input for uniform
  populations, and supports sampling with or without replacement. Exact
  sampling without replacement uses `torch.randperm` or a chunked exponential
  race, with an explicit low-memory Poisson-gap approximation for uniform
  sampling. This removes the `torch.multinomial` `2^24` category limit for
  sampling without replacement, consolidates duplicated Poisson index
  samplers, and fixes incorrect chunk-local indices and biased per-chunk quotas
  in DoMINO.
- Unified external aerodynamics recipe: the aggregate metrics reported for
  vector fields under the bare field name (e.g. `wss_l2`, likewise `_l1` /
  `_mae`) were computed on per-point vector magnitudes, so direction errors
  were invisible — a prediction with the correct magnitude but wrong direction
  at every point scored 0. The bare-name aggregate is now computed over all
  components jointly (whole-field relative norms, Frobenius for `l2`). The
  broken magnitude-only aggregate is not retained under a separate key.
  Per-component metrics (`wss_x_l2`, ...) were always direction-sensitive and
  are unchanged, and training/checkpoints are unaffected (the training
  objective goes through `LossCalculator`, not this metric path) — only
  reported aggregate vector metrics were misleading.
- Unified external aerodynamics recipe: model templates can now carry
  known-good training overrides (`train.yaml`'s `_self_` merges before the
  model template; all existing templates resolve identically). The GLOBE
  example now uses the recipe's default `compile` and learning-rate
  settings — both measured equivalent or better than the previously
  documented overrides on the DrivAerML surface case — and no longer sets
  `training.field_weights={pressure: 1.0, wss: 100.0}`, which was redundant
  with `NormalizeMeshFields` normalization and starved the pressure field
  of gradient signal (~2x worse converged pressure L2 at equal WSS L2).
- `ShardTensor` now survives `torch.compile` / AOTAutograd for tensor-subclass
  users: `__tensor_unflatten__` no longer forces `requires_grad` on the
  reconstructed inner (matching DTensor, so the inner/wrapper flags cannot
  disagree and trip `assert_metadata_eq` under a Dynamo graph-break re-fake),
  and `__coerce_same_metadata_as_tangent__` is subclass-friendly — it accepts a
  subclass's nested flatten context, treats empty and `None` sharding-shape maps
  as equal, and rebuilds a differing `ShardTensor`-subclass tangent via that
  type's own `__tensor_unflatten__` instead of returning `None` (the plain-tensor
  / `DTensor` cross-type `None` convention is preserved).
- `ShardTensor.to_local()` (and op-result forwards feeding it) is now
  differentiable under `torch.compile` / AOTAutograd. Previously the compiled
  backward was silently dropped (zero / missing gradient): ShardTensor's
  `__torch_function__` eager fallback converts to `DTensor` through
  `autograd.Function`s that AOTAutograd traces *through*, severing the primal's
  gradient connection during the joint trace. Under tracing, unpatched ops now
  pass through to `__torch_dispatch__` (mirroring `DTensor`, which defines no
  `__torch_function__`), keeping the graph differentiable while eager behavior
  and registered shard patches are unchanged.
- Datapipe contiguous-block subsampling now wraps cyclically, giving boundary
  and interior elements equal inclusion probability.
- Cell-subsampled GLOBE inputs now retain their effective integration measure,
  preventing area-weighted outputs and gradients from collapsing.
- `SetGlobalField` now writes injected fields to the domain-level `global_data`
  of a `DomainMesh`, in addition to the existing per-sub-mesh broadcast.
  Previously, code reading `DomainMesh.global_data` never saw the injected
  fields.
- `physicsnemo.mesh.io.from_pyvista(..., force_copy=True)` now copies attached
  point, cell, and global data as well as geometry. The matching new
  `to_pyvista(..., force_copy=True)` option prevents exported PyVista geometry
  and data from mutating the source `Mesh` through shared CPU storage.
- `physicsnemo.mesh.io.from_pyvista` now supports native line/poly-line grids,
  pixels, triangle strips, and pentagonal/hexagonal prisms, and selects explicit
  dimensions from mixed `UnstructuredGrid` inputs while preserving selected
  parent data. Explicit 1D conversion still derives the unique edge graph when
  no native lines exist. Connectivity and attached-data invariants are validated
  before VTK filters run. Unsupported higher-order topology is rejected pending
  globally conforming tessellation, while explicit vertex point-cloud conversion
  remains available without interpreting that topology. Centroid conversion
  rejects parents that cannot preserve cell-data alignment.
- `physicsnemo.mesh.sampling.sample_data_at_points` now handles integer and
  boolean fields by returning `float64`, so NaN sentinels and non-integral
  interpolation or multi-cell means are representable (subject to the usual
  `float64` precision limits). Point-data interpolation now promotes field and
  geometry dtypes consistently, and accumulation uses fewer full-sized
  temporaries and CUDA host synchronizations.
- `Mesh.point_data_to_cell_data` now handles integer and boolean point fields
  by returning `float64`, instead of raising `mean(): could not infer output
  dtype`. A mean of integers is generally non-integral, so it is computed in
  floating point (subject to the usual `float64` precision limits). This
  matches `Mesh.cell_data_to_point_data`, which already promoted discrete
  fields the same way; floating-point and complex fields are unaffected.
- `physicsnemo.mesh.projections.extrude` now produces a *conforming* (crack-free)
  simplicial complex for multi-cell inputs. Each prism was previously tessellated
  using the per-cell local vertex order, so adjacent cells that listed a shared
  edge's endpoints in different orders split the shared quad face along opposite
  diagonals; the resulting non-manifold volume leaked interior crack faces into
  `get_boundary_mesh` (boundary edges shared by 4 faces — e.g. an extruded L-shape
  or any multi-column grid, which also broke `repair.fix_orientation`). Parent-cell
  vertices are now sorted into a global order before tessellation (the
  Freudenthal-Kuhn subdivision), a no-op for already-sorted inputs.
- `physicsnemo.mesh.generate.marching_cubes` now accepts `bfloat16` fields by
  converting them to `float32` before crossing the NumPy boundary.
- `physicsnemo.mesh.projections.extrude` now returns consistently oriented cells
  for full-dimensional (codimension-0) output.
- `physicsnemo.mesh.remeshing.remesh` now preserves the input mesh's device and
  floating dtype instead of dropping them to CPU/float32.
- `physicsnemo.mesh.io.to_pyvista` now preserves supported dtypes for attached
  point, cell, and global data instead of narrowing every array to `float32`.
  Reduced-precision floating-point values are promoted only as needed for VTK.
- `physicsnemo.mesh.io.from_pyvista` and `to_pyvista` now preserve `float64`
  point coordinates instead of unconditionally narrowing geometry to `float32`,
  which could collapse small features on meshes with large coordinate offsets.
  Existing `float32` geometry remains `float32`.
- `physicsnemo.mesh`: `Mesh.to(<float dtype>)` and `DomainMesh.to(<float dtype>)`
  raised `TypeError: cells must have an int-like dtype` because the cast was applied
  to the integer `cells` tensor. A floating/complex dtype is now applied only to
  floating tensors; the integer `cells` (and any integer data) are preserved. Device
  moves are unchanged.
- `physicsnemo.mesh`: fixed several silent-wrong-result bugs — `slice_cells`
  carried stale point-level and non-local (`gaussian_curvature`) caches onto the
  sliced mesh; the intrinsic LSQ gradient returned all-zeros for codimension >= 2
  manifolds (now estimates the tangent space via local PCA); `smooth_laplacian`
  returned stale geometry caches after its in-place point update; `transform`
  propagated an incorrect point-normals cache under anisotropic/shear maps; and the
  derived-mesh methods (`compute_point_derivatives`, `compute_cell_derivatives`,
  `cell_data_to_point_data`, `point_data_to_cell_data`) aliased the source mesh's
  mutable `_cache`.
- `physicsnemo.mesh.spatial.ClusterTree.compute_source_aggregates` now
  normalizes with its call-time area weights instead of the weights used when
  constructing the tree, preserving correct aggregates when weights change.
- `physicsnemo.mesh`: fixed crash / data-integrity bugs — `project(...)` with
  `transform_point_data`/`transform_cell_data=True` mutated the input mesh in
  place; visualization and `to_pyvista` crashed on autograd-tracked tensors (now
  detached before `.numpy()`); and integer/bool data crashed (`safe_eps` on an
  integer dtype) or truncated via integer division during facet/scatter
  aggregation (now computed in a floating dtype).
- `physicsnemo.mesh`: averaging a complex point or cell field no longer silently
  returns `float64` with the imaginary part discarded. Complex tensors are not
  "floating point" by `torch`'s definition, so facet/scatter aggregation
  promoted them like an integer field, corrupting
  `Mesh.cell_data_to_point_data`, `Mesh.get_facet_mesh` (both `data_source`
  settings), and `repair.merge_duplicate_points`. A `"mean"` still requires
  real weights, because its divisor is clamped away from zero and `clamp`
  rejects complex dtypes; a `"sum"` accepts complex weights and promotes to the
  common dtype of the values and the weights.
- `physicsnemo.mesh` Morton-code quantization now handles empty inputs, tiny
  extents, half-precision coordinates, and one-dimensional endpoints correctly.
- `physicsnemo.mesh`: fixed Loop subdivision pulling open boundaries inward (now
  applies the boundary/crease mask); subdivision zero-filling integer/bool
  `point_data` at new edge vertices (now inherits a parent label);
  non-deterministic orientation flips and over-counted component sizes in
  `repair.fix_orientation`; random point sampling drawing barycentric weights in
  float32 for float64 meshes; and `Mesh.merge` not validating `point_data` /
  `global_data` key consistency.
- Fixed `DefaultTrainingLoop` reading `DistributedManager.device` at the class
  level (a `property` descriptor) instead of `DistributedManager().device`, which
  left the loop's device set to a `property` object under an initialized
  `DistributedManager` (`physicsnemo/active_learning/loop.py`).
- Replaced three plain-string regex / docstring literals containing invalid
  escape sequences with raw-string equivalents
  (`physicsnemo/utils/logging/launch.py`,
  `physicsnemo/metrics/general/calibration.py`,
  `physicsnemo/metrics/general/crps.py`); these were `SyntaxWarning`s today
  and become `SyntaxError`s in Python 3.16.
- Various test cleanups to remove self-inflicted warnings in CI output:
  disabled pytest collection for `TestModelA`/`TestModelB` helpers in
  `test/core/test_registry.py` via `__test__ = False`; migrated
  `test/nn/module/test_interpolation.py` to call the non-deprecated
  `grid_to_point_interpolation` and added a dedicated test for the
  deprecation alias; scoped a `lr_scheduler.step()`-before-`optimizer.step()`
  `UserWarning` filter to a single test in
  `test/optim/test_combined_optimizer.py`; guarded the
  `DistributedManager.initialize()` calls in `test/utils/test_checkpoint.py`
  with `is_initialized()`; and suppressed the import-time
  `ExperimentalFeatureWarning` in `test/datapipes/healda/test_features.py`
  via `warnings.catch_warnings()`.
- Fixed `physicsnemo.utils.get_checkpoint_dir` returning paths with `\`
  separators on Windows (e.g. `.\checkpoints_model`), which was inconsistent
  with the `/`-based paths used elsewhere in the checkpoint utilities and
  broke the `test_get_checkpoint_dir` CI test on Windows. The function now
  always joins with `/`, working uniformly for local paths and `fsspec`
  URIs (`msc://`, etc.) across operating systems.

### Security

### Dependencies

- Raises the minimum TensorDict version to `tensordict[zarr]>=0.14.0`,
  restoring the stable `tensordict` distribution while retaining Zarr support
  and upstream bug fixes.
- Removes `pyacvd` from the `mesh-extras` optional dependencies. Remeshing now
  uses NVIDIA Warp.
- Updates the minimum supported `warp-lang` version to 1.14.0.

## [2.1.0] - 2026-05-26

### Added

- Adds GLOBE model (`physicsnemo.experimental.models.globe.model.GLOBE`),
  including new variant that uses a dual tree traversal algorithm to reduce the
  complexity of the kernel evaluations from O(N^2) to O(N).
- Adds GLOBE AirFRANS example case (`examples/cfd/external_aerodynamics/globe/airfrans`)
- Adds GLOBE DrivAerML example case (`examples/cfd/external_aerodynamics/globe/drivaer`)
- Adds drop-test dynamics recipe.
- Adds concrete dropout uncertainty quantification for GeoTransolver. Learnable
  per-layer dropout rates enable MC-Dropout inference for uncertainty
  estimates. Disabled by default (`concrete_dropout: false`).
- Adds automatic support for `FSDP` and/or `ShardTensor` models in checkpoint save/load
  functionality
- PhysicsNeMo-Mesh now supports conversion from PyVista/VTK/VTU meshes that may
  contain polyhedral cells.
- In PhysicsNeMo-Mesh, adds `Mesh.to_point_cloud()`, `.to_edge_graph()`, and
  `.to_dual_graph()` methods. These allow Mesh conversion to 0D point clouds, 1D
  edge graphs, and 1D dual graphs, respectively, when connectivity information
  is not needed.
- Adds `physicsnemo.mesh.generate` subpackage with `marching_cubes` for
  isosurface extraction from 3D scalar fields, returning a `Mesh` object.
  Supports the NVIDIA Warp backend.
- Adds a type system to PhysicsNeMo-Mesh, allowing annotation of Mesh dimensions
  using notation like `Mesh[2, 3]` for a 2D manifold in 3D space.
- Adds adjacency caching to PhysicsNeMo-Mesh `Mesh` objects, allowing efficient
  reuse of neighbor information.
- Adds `DomainMesh` class for grouping an interior mesh with named boundary
  meshes and domain-level metadata, with passthrough geometric transforms
  (translate, rotate, scale, transform) and data operations.
- Allows selective per-field transformation of `Mesh` objects: `transform_point_data`,
  `transform_cell_data`, and `transform_global_data` now accept `bool | TensorDict`
  (or plain `dict` for convenience).
- Adds `physicsnemo.mesh.remeshing` subpackage with `partition_cells()` for
  creating Voronoi regions around seed points. BVH-accelerated.
- Added support for 1D, 2D, and 3D neighborhood attention (natten) via
  `physicsnemo.nn.functional` interface, with full `ShardTensor` support.
- Added derivative functionals in `physicsnemo.nn.functional` for
  `uniform_grid_gradient`, `rectilinear_grid_gradient`,
  `spectral_grid_gradient`, `meshless_fd_derivatives`, `mesh_lsq_gradient`,
  and `mesh_green_gauss_gradient`.
- Adds `physicsnemo.sym` module for symbolic PDE residual computation
  (`PhysicsInformer`). Users define PDEs via SymPy and select a gradient method
  (`autodiff`, `finite_difference`, `spectral`, `meshless_finite_difference`,
  `least_squares`); spatial derivatives are computed automatically using the
  `nn.functional.derivatives` functionals.
- Ports all physics-informed examples (LDC PINNs, Darcy, Stokes MGN, DoMINO,
  datacenter, xaeronet, MHD/SWE PINO) to the new `physicsnemo.sym` interface,
  replacing the separate `physicsnemo-sym` package dependency. Geometry is now
  handled via `physicsnemo.mesh` and PyVista.
- Added geometry functionals in `physicsnemo.nn.functional` for
  `mesh_poisson_disk_sample`, `mesh_to_voxel_fraction`, and
  `signed_distance_field`.
- Added rendering functionals in `physicsnemo.nn.functional` for isosurface,
  mesh, volume, LIC, point cloud, wireframe, and RGBA transfer rendering, with
  Warp kernels for rendering and PyTorch fallbacks for transfer functions.
- Adds embedded OOD guardrail `OODGuard` at
  `physicsnemo.experimental.guardrails.embedded`, optionally
  wired into `GeoTransolver` via a new `guard_config` constructor argument.
  The guard calibrates per-channel global bounds and a geometry-latent
  kNN threshold during training, and emits warnings on out-of-distribution
  inputs at inference.
- In PhysicsNeMo-Mesh, `physicsnemo.mesh.geometry` now publicly exposes
  `stable_angle_between_vectors` and `compute_triangle_angles` (previously
  only available via the private `physicsnemo.mesh.curvature._utils`).
- PhysicsNeMo Datapipes enables reproducability through `torch.generator`
  utilities.
- PhysicsNeMo Datapipes now supports `physicsnemo.mesh.Mesh` and
  `physicsnemo.mesh.DomainMesh` objects for deserialization, with
  transformations and utilities for mesh-based datasets.
- PhysicsNeMo Datapipes now support `MultiDataset` construction,
  allowing on-the-fly construction of multi-source composite datasets
  that can be sampled and processed efficiently and coherently
  as one dataset.
- PhysicsNeMo Datapipes also support random augmentations for
  mesh-based datapipes, leveraging `torch.distributions` for
  broad random distribution support. Mesh and DomainMesh
  datasets allow random translation, scaling, and rotation
  of mesh data in coherent ways, compatible with reproducability
  features of physicsnemo datapipes.
- Adds a new *unified* training recipe for external aerodynamics
  that supports training on multiple datasets (DrivaerML, ShiftSUV,
  HighLiftAeroML, or more, bring your own, mix and match), supports
  training several different models (Domino, Transolver, GeoTransolver,
  Flare, GeoTransolver with Flare-attention, bring your own!).  Leverages
  mesh datasets and non-dimensionalization to enable dataset mixing and
  matching at runtime.  Train with surface or volume data.
- Adds a new `physicsnemo.diffusion.multi_diffusion` subpackage that
  scales 2D diffusion models to large domains via patch-based training
  and inference. Provides `MultiDiffusionModel2D` (wraps a base model and
  handles state patching, conditioning preprocessing, positional-embedding
  injection, and per-patch output fusion), the
  `MultiDiffusionMSEDSMLoss` / `MultiDiffusionWeightedMSEDSMLoss` losses
  for patch-based DSM training, and `MultiDiffusionPredictor` for
  sampling (plugs straight into `sample()` / `get_denoiser()` and the
  standard solvers). Patching primitives (`BasePatching2D`,
  `GridPatching2D`, `RandomPatching2D`) are exposed under the same
  subpackage and are `torch.compile`-friendly with `fullgraph=True`.
  `MultiDiffusionPredictor` supports memory-efficient inference on
  large domains via `chunk_size` and `use_checkpointing`. The
  subpackage also ships patch-local DPS guidance:
  `MultiDiffusionDPSScorePredictor` (drop-in score predictor that plugs
  into the standard sampling stack),
  `MultiDiffusionDataConsistencyDPSGuidance` for inpainting and sparse
  data assimilation, and `MultiDiffusionModelConsistencyDPSGuidance` for
  generic patch-local observation operators. Use these instead of the
  global `DPSScorePredictor` to run guided sampling on domains that
  would otherwise OOM.
- Adds `"epsilon"` as a supported prediction type throughout the diffusion
  framework, alongside the existing `"x0"` and `"score"` modes. A new
  `PredictorType = Literal["x0", "score", "epsilon"]` alias in
  `physicsnemo.diffusion.base` is wired through losses (`MSEDSMLoss`,
  `WeightedMSEDSMLoss`, and the multi-diffusion losses), preconditioners,
  samplers / solvers, DPS guidance, and noise schedulers, enabling
  end-to-end training and sampling of epsilon-parameterized models.
  Losses gain an `epsilon_to_x0_fn` kwarg used for the epsilon-to-x0
  conversion required during DSM training.
- Added support for Batched radius search, which enables Domino
  and GeoTransolver with local features and batch size > 1.
- Added the underfill recipe.

### Changed

- Improved crash recipe with configurable stats directory.
- `physicsnemo.mesh.sampling.find_nearest_cells` uses a KNN-backed
  implementation, and no longer accepts the `bvh=`, `chunk_size=`,
  `max_rounds=`, or `max_candidates_per_point=` parameters.
- &#9888;&#65039; **BC-impact (deep imports):** internal `physicsnemo.nn.functional`
  modules were reorganized by category. Public top-level functional imports are
  unchanged, but code importing internal module paths directly (for example
  `physicsnemo.nn.functional.knn` or
  `physicsnemo.nn.functional.radius_search`) should migrate to
  `physicsnemo.nn.functional.neighbors.*`.
- Consolidated Warp interpolation kernels for grid-to-point and point-to-grid
  backends, and added missing kernel/helper docstrings.
- In PhysicsNeMo-Mesh, dual-mesh primitives gained closed-form fast paths
  for triangle meshes embedded in 3D. `compute_circumcenters` is up to
  ~10000x faster (e.g. 11 s -> ~1 ms on a 360 K-triangle AirFRANS mesh,
  RTX 4090) by replacing batched `torch.linalg.lstsq` over (2, 3) systems
  with a closed-form cross product, and `compute_vertex_angles` is up to
  ~15x faster on the same meshes by replacing the dimension-agnostic
  Gram-determinant formula with an `atan2(||cross||, dot)` formulation.
  Anything that depends on these (Gaussian curvature, FEM Laplacian,
  cotangent weights, Voronoi areas, smoothing) inherits the speedup. See
  `perf.md` for the full audit.
- In PhysicsNeMo-Mesh, BVH construction is faster on GPU.
  `_compute_morton_codes` has a CUDA-specific fused-bits path that
  eliminates the `n_bits` sequential kernel launches of the previous
  bit-loop (5-8x speedup on small / medium meshes), and `BVH.from_mesh`
  reuses the cached `Mesh.cell_centroids` instead of recomputing.
  End-to-end `BVH.from_mesh` is ~2x faster on a 162 K-tet `cube_volume`
  mesh.
- In PhysicsNeMo-Mesh, the topology-dedup APIs
  (`categorize_facets_by_count`, `find_edges_in_reference`,
  `remove_duplicate_cells`, `build_adjacency_from_pairs`) gained optional
  `index_bound` / `n_targets` parameters. When the caller passes a strict
  upper bound (typically `mesh.n_points` or `mesh.n_cells`), the implicit
  `tensor.max().item()` GPU sync is avoided and the dedup uses a packed
  int64 unique (via the new internal `unique_index_tuples`) and a single
  composite-key argsort. End-to-end `get_boundary_edges` and
  `cell_to_cells_adjacency` are ~2x faster on practical-size unstructured
  meshes (e.g. 360 K-triangle AirFRANS).
- &#9888;&#65039; **BC-impact (deep imports):** in PhysicsNeMo-Mesh,
  `stable_angle_between_vectors` and `compute_triangle_angles` moved from
  `physicsnemo.mesh.curvature._utils` to `physicsnemo.mesh.geometry._angles`.
  The old private path is no longer available; use the
  `physicsnemo.mesh.geometry` re-export instead.
- &#9888;&#65039; **BC-impact (pre-release rename):** in PhysicsNeMo-Mesh,
  `DomainMesh.apply` was renamed to `DomainMesh.apply_to_meshes`. The
  original name shadowed the recursive `Tensor -> Tensor` `apply` method
  that `@tensorclass` auto-injects, breaking duck-type symmetry with
  `Mesh.apply` for any code that handled both classes. After the rename,
  `dm.apply(tensor_fn)` works as expected (recurses through every leaf
  tensor in `interior`, `boundaries`, and `global_data`); the original
  Mesh-to-Mesh broadcast is now `dm.apply_to_meshes(mesh_fn)`. Early
  adopters of the unreleased `DomainMesh` API should rename their
  `.apply(...)` callsites to `.apply_to_meshes(...)`.
- Refactored the patching utilities under
  `physicsnemo.diffusion.multi_diffusion.patching`. Patching and fusion
  operations are now more performant and `torch.compile`-friendly (e.g.
  `fullgraph=True`,`error_on_recompile=True`).
- Refactored the `examples/geophysics/diffusion_fwi` full-waveform
  inversion example to use the consolidated `physicsnemo.diffusion` API
  (preconditioners, samplers, losses, DPS guidance) and removed the
  recipe-local copies of these utilities under `utils/`.
- Refactored the `examples/generative/topodiff` recipe to use the
  consolidated `physicsnemo.diffusion` API (`MSEDSMLoss` with
  `prediction_type="epsilon"`, `sample()`, `DPSScorePredictor`) plus a
  recipe-local DDPM scheduler, solver, and classifier guidance. Removed
  the now-unused `Diffusion`, `DatasetTopoDiff`, and `load_data_topodiff`
  abstractions from `physicsnemo.models.topodiff`.
- Significantly expanded CI test coverage for `physicsnemo.diffusion`,
  including new tests for samplers, solvers, preconditioners, losses,
  DPS guidance, multi-diffusion, and patching utilities, plus
  combined-workflow and from-checkpoint round-trip tests. Most tests
  run with `fullgraph=True` and `error_on_recompile` to catch
  `torch.compile` regressions.
- Internal weight initialization in the distributed AFNO layers and the
  `EarthAttention` blocks of `physicsnemo.nn.module.attention_layers` now
  dispatches to `torch.nn.init.trunc_normal_` directly instead of going
  through frozen in-tree copies of the pre-PyTorch-2.12 inverse-CDF
  implementation. PyTorch 2.12 reimplemented `trunc_normal_` as a
  rejection-sampling loop on top of `normal_()` (see
  [pytorch/pytorch#174997](https://github.com/pytorch/pytorch/pull/174997)),
  so seeded from-scratch initialization consumes the RNG stream
  differently on 2.12+ vs older versions. Existing trained checkpoints
  are unaffected (loading bypasses init). Forward-accuracy reference
  outputs for `AFNO`, `ModAFNO`, `Transolver`, `FLARE`, and `Pangu` were
  regenerated against the new algorithm. Rather than wiring per-model
  skips, `test.common.validate_forward_accuracy` now uniformly skips on
  `torch < 2.12` (the reference data is locked to that floor via a single
  `_REFERENCE_DATA_MIN_TORCH` constant; bump it when a PyTorch
  release next changes an init/RNG algorithm any forward-accuracy model
  depends on, and regenerate the `.pth` files at the same time).

### Deprecated

- `physicsnemo.utils.mesh` is deprecated and will be removed in v2.2.0. For
  isosurface extraction, use `physicsnemo.mesh.generate.marching_cubes` instead
  of `sdf_to_stl`. For VTP/OBJ/STL file conversion (`combine_vtp_files`,
  `convert_tesselated_files_in_directory`), use VTK or PyVista directly.
- `physicsnemo.nn.module.utils.trunc_normal_` (and its submodule path
  `physicsnemo.nn.module.utils.weight_init.trunc_normal_`) is deprecated
  and will be removed in v2.2.0. It is now a thin wrapper around
  `torch.nn.init.trunc_normal_` that emits a `DeprecationWarning` on
  call, replacing the frozen in-tree copy of the legacy inverse-CDF
  implementation. Use `torch.nn.init.trunc_normal_` directly.
- Deprecates the CorrDiff example (`examples/weather/corrdiff`), which no longer
  receives maintenance, bug fixes, or new features. Use the regional
  high-resolution weather model example
  (`examples/weather/regional_weather_diffusion`) instead.
  That example unifies regional diffusion-based weather models, and covers the
  CorrDiff downscaling setting alongside other diffusion-based settings.

### Removed

- The legacy in-tree `trunc_normal_` implementation that lived in
  `physicsnemo/models/afno/distributed/layers.py` (`_trunc_normal_` /
  `_no_grad_trunc_normal_`) is removed. These names were private; all
  in-tree call sites now use `torch.nn.init.trunc_normal_`.

### Fixed

- Fixed functional benchmark plot fallback labeling so unlabeled ASV results use
  the same key ordering as the benchmark runner.
- Fixed graph break caused by `FunctionSpec` dispatch (`max(key=)` is not supported by `torch.compile`)
- Fixed bug in Pangu, FengWu attention window shift for asymmetric longitudes
- Fixed a bug in `mesh.sampling.find_nearest_cells`, where a mixup between L2 and L-inf
  norms could cause slightly incorrect nearest-neighbor assignments in highly skewed
  meshes.
- Fixed TensorDict key-ordering bug in GLOBE's Barnes-Hut kernel that caused
  incorrect results when `tensordict >= 0.12` reordered leaves during
  TensorDict construction from dict literals mixing plain and nested keys.
- In PhysicsNeMo-Mesh, `from_pyvista` now correctly handles
  `UnstructuredGrid` inputs in newer `pyvista` versions, looking up
  cell-type buckets in `cells_dict` with `np.uint8(pv.CellType.X)` keys
  rather than the `IntEnum` value, and skipping non-numeric VTK arrays
  (strings, objects) when copying point / cell / field data into the
  `Mesh` `TensorDict`s instead of failing the conversion.
- In PhysicsNeMo-Mesh, the `Mesh` constructor now preserves data when
  `point_data` / `cell_data` / `global_data` are passed as a non-dict
  `Mapping` (notably PyVista's `DataSetAttributes`). Previously, with
  `tensordict >= 0.12`, the `@tensorclass(tensor_only=True)` auto-init
  silently wrapped such Mappings as `NonTensorData` and dropped every key,
  so e.g. `Mesh(cell_data=pv_mesh.cell_data, ...)` produced an empty
  `cell_data`. `Mesh.__post_init__` now detects this wrapping and unwraps
  the original Mapping before coercing to `TensorDict`. The `tensor_only`
  fast path is preserved, so internal Mesh constructions (slicing,
  transforms, `from_pyvista`) keep their full speed. Backed by new direct-
  construction regression tests, a `cell_data` / `global_data` memmap
  round-trip test, and a committed `.pmsh` golden fixture that locks the
  on-disk format against silent breakage in future changes.
- In PhysicsNeMo-Mesh, `safe_eps(dtype)` is now capped at
  `torch.finfo(dtype).eps`, which fixes a float16 corner case where the
  previous `tiny ** 0.25` floor exceeded machine epsilon and could
  corrupt fp16 mesh quantities. Ad-hoc `+ 1e-10` denominators in
  `smooth_laplacian` and `compute_quality_metrics` have been replaced
  with the dtype-aware `.clamp(min=safe_eps(dtype))` to avoid silently
  zeroing fp16 weights.
- Fixed a silent bug in loading state from checkpoint for
  FSDP-backed models with `use_orig_params=False` and channels last
  memory format.
- Fixed issues with physicsnemo.nn.functional's `radius_search` that
  caused crashes when used with torch.compile.
- Fixed the sinusoidal positional embeddings formula in `SongUNet` and
  `MultiDiffusionModel2D` so it now follows the standard `sin / cos`
  convention. Affected reference data was regenerated.
- Constructing a `Mesh` (or `DomainMesh`) inside a `torch.compile`-traced
  function no longer raises `AttributeError` / `KeyError` or silently
  produces wrong output. The breakage came from two regressions in
  `tensordict >= 0.12.0` (PR `pytorch/tensordict#1552`), where the
  `@tensorclass` init wrapper's bypass branch silently skipped both
  field-default normalization and `__post_init__` under
  `torch.compile`. We pin `tensordict < 0.12` until the upstream fix
  (`pytorch/tensordict#1708`, `pytorch/tensordict#1709`) ships, and add
  a regression test (`test/mesh/mesh/test_compile.py`) that constructs
  a `Mesh` inside `torch.compile` and reads cached properties, so the
  same bug cannot return on a future pin bump unnoticed.

### Dependencies

- Increments minimum viable PyTorch version to `torch>=2.5.0` to support FSDP better
- Upper-bounds `tensordict < 0.12` to avoid the `torch.compile` regressions
  in `tensordict >= 0.12.0` (see corresponding entry under Fixed).

## [2.0.0] - 2026-03-09

### Added

- Refactored diffusion preconditioners in
  `physicsnemo.diffusion.preconditioners` relying on a new abstract base class
  `BaseAffinePreconditioner` for preconditioning schemes using affine
  transformations. Existing preconditioners (`VPPrecond`, `VEPrecond`,
  `iDDPMPrecond`, `EDMPrecond`) reimplemented based on this new interface.
- New `physicsnemo.experimental.nn.symmetry` module that implements building
  blocks that preserve 2D and 3D rotational equivariance using a
  grid-based layout for efficient GPU parallelization, and an emphasis on
  compact `einsum` operations.
- Flare attention support for both Transolver and GeoTransolver models.

### Changed

- PhysicsNemo v2.0 contains significant reorganization of tools.  Please see
  the v2.0-MIGRATION-GUIDE.md to understand what has changed and why.
- DiT (Diffusion Transformer) has been moved from `physicsnemo.experimental.models.dit`
  to `physicsnemo.models.dit`.

### Fixed

- Shape mistmatch bug in the Lennard Jones example

### Dependencies

- CUDA backend is now selected via orthogonal `cu12` / `cu13` extras rather
  than being hardcoded to CUDA 13. Feature extras (`nn-extras`, `utils-extras`,
  etc.) are now CUDA-agnostic and can be combined with either backend, e.g.
  `pip install "nvidia-physicsnemo[cu13,nn-extras]"`. When neither `cu12` nor
  `cu13` is specified, PyTorch is installed from PyPI using its default build
  (currently CUDA 12.8 on Linux). For development with `uv`, use
  `uv sync --extra cu13` (or `--extra cu12`) to select the backend.

## [1.3.0] - 2025-11-17

### Added

- Added mixture_of_experts for weather example in physicsnemo.examples.weather.
  **⚠️Warning:** - It uses experimental DiT model subject to future API changes.
  Added some modifications to DiT architecture in physicsnemo.experimental.models.dit.
  Added learnable option to PositionalEmbedding in physicsnemo.models.diffusion.layers.
- Added lead-time aware training support to the StormCast example.
- Add a device aware kNN method to physicsnemo.utils.neighbors. Works with CPU or GPU
  by dispatching to the proper optimized library, and torch.compile compatible.
- Added additional testing of the DoMINO datapipe.
- Examples: added a new example for full-waveform inversion using diffusion
  models. Accessible in `examples/geophysics/diffusion_fwi`.
- Domain Parallelism: Domain Parallelism is now available for kNN, radius_search,
  and torch.nn.functional.pad.
- Unified recipe for crash modeling, supporting Transolver and MeshGraphNet,
  and three transient schemes.
- Added a check to `stochastic_sampler` that helps handle the `EDMPrecond` model,
  which has a specific `.forward()` signature
- Examples: added a new example for reservoir simulation using X-MeshGraphNet.
  Accessible in `examples/reservoir_simulation`
- Added abstract interfaces for constructing active learning workflows, contained
  under the `physicsnemo.active_learning` namespace. A preliminary example of how
  to compose and define an active learning workflow is provided in `examples/active_learning`.
  The `moons` example provides a minimal (pedagogical) composition that is meant to
  illustrate how to define the necessary parts of the workflow.
- Added a new example for temporal interpolation of weather forecasts using ModAFNO.
  Accessible in `examples/weather/temporal_interpolation`.

### Changed

- Migrated Stokes MGN example to PyTorch Geometric.
- Migrated Lennard Jones example to PyTorch Geometric.
- Migrated physicsnemo.utils.sdf.signed_distance_field to a static return,
  torch-only interface.  It also now works on distributed meshes and input fields.
- Refactored DiTBlock to be more modular
- Added NATTEN 2D neighborhood attention backend for DiTBlock
- Migrated blood flow example to PyTorch Geometric.
- Refactored DoMINO model code and examples for performance optimizations and improved readability.
- Migrated HydroGraphNet example to PyTorch Geometric.
- Support for saving and loading nested `physicsnemo.Module`s. It is now
  possible to create nested modules with `m = Module(submodule, ...)`, and save
  and load them with `Module.save` and `Module.from_checkpoint`.
  **⚠️Warning:** - The modules have to be `physicsnemo.Module`s, and not
  `torch.nn.Module`s.
- Support passing custom tokenizer, detokenizer, and attention `Module`s in
  experimental DiT architecture
- Improved Transolver training recipe's configuration for checkpointing and normalization.
- Bumped `multi-storage-client` version to 0.33.0 with rust client.
- Improved configuration for DLWP Healpix (checkpoint directory) and GraphCast (W&B settings).

### Fixed

- Set `skip_scale` to Python float in U-Net to ensure compilation works.
- Ensure stream dependencies are handled correctly in physicsnemo.utils.neighbors
- Fixed the issue with incorrect handling of files with consecutive runs of
  `combine_stl_solids.py` in the X-MGN recipe.
- Fixed the `RuntimeError: Worker data receiving interrupted` error in the datacenter example.

## [1.2.0] - 2025-08-26

### Added

- Diffusion Transformer (DiT) model. The DiT model can be accessed in
 `physicsnemo.experimental.models.dit.DiT`. **⚠️Warning:** - Experimental feature
  subject to future API changes.
- Improved documentation for diffusion models and diffusion utils.
- Safe API to override `__init__`'s arguments saved in checkpoint file with
  `Module.from_checkpoint("chkpt.mdlus", override_args=set(...))`.
- PyTorch Geometric MeshGraphNet backend.
- Functionality in DoMINO to take arbitrary number of `scalar` or `vector`
  global parameters and encode them using `class ParameterModel`
- TopoDiff model and example.
- Added ability for DoMINO model to return volume neighbors.
- Added functionality in DoMINO recipe to introduce physics residual losses.
- Diffusion models, metrics, and utils: implementation of Student-t
  distribution for EDM-based diffusion models (t-EDM). This feature is adapted
  from the paper [Heavy-Tailed Diffusion Models, Pandey et al.](https://arxiv.org/abs/2410.14171>).
  This includes a new EDM preconditioner (`tEDMPrecondSuperRes`), a loss
  function (`tEDMResidualLoss`), and a new option in corrdiff `diffusion_step`.
  &#9888;&#65039; This is an experimental feature that can be accessed through the
  `physicsnemo.experimental` module; it might also be subjected to API changes
  without notice.
- Bumped Ruff version from 0.0.290 to 0.12.5. Replaced Black with `ruff-format`.
- Domino improvements with Unet attention module and user configs
- Hybrid MeshGraphNet for modeling structural deformation
- Enabled TransformerEngine backend in the `transolver` model.
- Inference code for x-meshgraphnet example for external aerodynamics.
- Added a new example for external_aerodynamics: training `transolver` on
  irregular mesh data for DrivaerML surface data.
- Added a new example for external aerodynamics for finetuning pretrained models.

### Changed

- Diffusion utils: `physicsnemo.utils.generative` renamed into `physicsnemo.utils.diffusion`
- Diffusion models: in CorrDiff model wrappers (`EDMPrecondSuperResolution` and
  `UNet`), the arguments `profile_mode` and `amp_mode` cannot be overriden by
  `from_checkpoint`. They are now properties that can be dynamically changed
  *after* the model instantiation with, for example, `model.amp_mode = True`
  and `model.profile_mode = False`.
- Updated healpix data module to use correct `DistributedSampler` target for
  test data loader
- Existing DGL-based vortex shedding example has been renamed to `vortex_shedding_mgn_dgl`.
  Added new `vortex_shedding_mgn` example that uses PyTorch Geometric instead.
- HEALPixLayer can now use earth2grid HEALPix padding ops, if desired
- Migrated Vortex Shedding Reduced Mesh example to PyTorch Geometric.
- CorrDiff example: fixed bugs when training regression `UNet`.
- Diffusion models: fixed bugs related to gradient checkpointing on non-square
  images.
- Diffusion models: created a separate class `Attention` for clarity and
  modularity. Updated `UNetBlock` accordingly to use the `Attention` class
  instead of custom attention logic. This will update the model architecture
  for `SongUNet`-based diffusion models. Changes are not BC-breaking and are
  transparent to the user.
- &#9888;&#65039; **BC-breaking:** refactored the automatic mixed precision
  (AMP) API in layers and models defined in `physicsnemo/models/diffusion/` for
  improved usability. Note: it is now, not only possible, but *required* to
  explicitly set `model.amp_mode = True` in order to use the model in a
  `torch.autocast` clause. This applies to all `SongUNet`-based models.
- Diffusion models: fixed and improved API to enable fp16 forward pass in
  `UNet` and `EDMPrecondSuperResolution` model wrappers; fp16 forward pass can
  now be toggled/untoggled by setting `model.use_fp16 = True`.
- Diffusion models: improved API for Apex group norm. `SongUNet`-based models
  will automatically perform conversion of the input tensors to
  `torch.channels_last` memory format when `model.use_apex_gn` is `True`. New
  warnings are raised when attempting to use Apex group norm on CPU.
- Diffusion utils: systematic compilation of patching operations in `stochastic_sampler`
  for improved performance.
- CorrDiff example: added option for Student-t EDM (t-EDM) in `train.py` and
  `generate.py`. When training a CorrDiff diffusion model, this feature can be
  enabled with the hydra overrides `++training.hp.distribution=student_t` and
  `++training.hp.nu_student_t=<nu_value>`. For generation, this feature can be
  enabled with similar overrides: `++generation.distribution=student_t` and
  `++generation.nu_student_t=<nu_value>`.
- CorrDiff example: the parameters `P_mean` and `P_std` (used to compute the
  noise level `sigma`) are now configurable. They can be set with the hydra
  overrides `++training.hp.P_mean=<P_mean_value>` and
  `++training.hp.P_std=<P_std_value>` for training (and similar ones with
  `training.hp` replaced by `generation` for generation).
- Diffusion utils: patch-based inference and lead time support with
  deterministic sampler.
- Existing DGL-based XAeroNet example has been renamed to `xaeronet_dgl`.
  Added new `xaeronet` example that uses PyTorch Geometric instead.
- Updated the deforming plate example to use the Hybrid MeshGraphNet model.
- &#9888;&#65039; **BC-breaking:** Refactored the `transolver` model to improve
  readability and performance, and extend to more use cases.
- Diffusion models: improved lead time support for `SongUNetPosLtEmbd` and
  `EDMLoss`. Lead-time embeddings can now be used with/without positional
  embeddings.
- Diffusion models: consolidate `ApexGroupNorm` and `GroupNorm` in
  `models/diffusion/layers.py` with a factory `get_group_norm` that can
  be used to instantiate either one of them. `get_group_norm` is now the
  recommended way to instantiate a GroupNorm layer in `SongUNet`-based and
  other diffusion models.
- Physicsnemo models: improved checkpoint loading API in
  `Module.from_checkpoint` that now exposes a `strict` parameter to raise error
  on missing/unexpected keys, similar to that used in
  `torch.nn.Module.load_state_dict`.
- Migrated Hybrid MGN and deforming plate example to PyTorch Geometric.

### Fixed

- Bug fixes in DoMINO model in sphere sampling and tensor reshaping
- Bug fixes in DoMINO utils random sampling and test.py
- Optimized DoMINO config params based on DrivAer ML

## [1.1.1] - 2025-06-16

### Fixed

- Fixed an inadvertent change to the deterministic sampler 2nd order correction
- Bug Fix in Domino model ball query layer
- Fixed bug models/unet/unet.py: setting num_conv_layers=1 gives errors

## [1.1.0] - 2025-06-05

### Added

- Added ReGen score-based data assimilation example
- General purpose patching API for patch-based diffusion
- New positional embedding selection strategy for CorrDiff SongUNet models
- Added Multi-Storage Client to allow checkpointing to/from Object Storage
- Added a new aerodynamics example using DoMINO to compute design sensitivities
  (e.g., drag adjoint) with respect to underlying input geometry.

### Changed

- Simplified CorrDiff config files, updated default values
- Refactored CorrDiff losses and samplers to use the patching API
- Support for non-square images and patches in patch-based diffusion
- ERA5 download example updated to use current file format convention and
  restricts global statistics computation to the training set
- Support for training custom StormCast models and various other improvements for StormCast
- Updated CorrDiff training code to support multiple patch iterations to amortize
  regression cost and usage of `torch.compile`
- Refactored `physicsnemo/models/diffusion/layers.py` to optimize data type
  casting workflow, avoiding unnecessary casting under autocast mode
- Refactored Conv2d to enable fusion of conv2d with bias addition
- Refactored GroupNorm, UNetBlock, SongUNet, SongUNetPosEmbd to support usage of
  Apex GroupNorm, fusion of activation with GroupNorm, and AMP workflow.
- Updated SongUNetPosEmbd to avoid unnecessary HtoD Memcpy of `pos_embd`
- Updated `from_checkpoint` to accommodate conversion between Apex optimized ckp
  and non-optimized ckp
- Refactored CorrDiff NVTX annotation workflow to be configurable
- Refactored `ResidualLoss` to support patch-accumlating training for
  amortizing regression costs
- Explicit handling of Warp device for ball query and sdf
- Merged SongUNetPosLtEmb with SongUNetPosEmb, add support for batch>1
- Add lead time embedding support for `positional_embedding_selector`. Enable
arbitrary positioning of probabilistic variables
- Enable lead time aware regression without CE loss
- Bumped minimum PyTorch version from 2.0.0 to 2.4.0, to minimize
  support surface for `physicsnemo.distributed` functionality.

### Dependencies

- Made `nvidia.dali` an optional dependency

## [1.0.1] - 2025-03-25

### Added

- Added version checks to ensure compatibility with older PyTorch for distributed
  utilities and ShardTensor

### Fixed

- `EntryPoint` error that occured during physicsnemo checkpoint loading

## [1.0.0] - 2025-03-18

### Added

- DoMINO model architecture, datapipe and training recipe
- Added matrix decomposition scheme to improve graph partitioning
- DrivAerML dataset support in FIGConvNet example.
- Retraining recipe for DoMINO from a pretrained model checkpoint
- Prototype support for domain parallelism of using ShardTensor (new).
- Enable DeviceMesh initialization via DistributedManager.
- Added Datacenter CFD use case.
- Add leave-in profiling utilities to physicsnemo, to easily enable torch/python/nsight
  profiling in all aspects of the codebase.

### Changed

- Refactored StormCast training example
- Enhancements and bug fixes to DoMINO model and training example
- Enhancement to parameterize DoMINO model with inlet velocity
- Moved non-dimensionaliztion out of domino datapipe to datapipe in domino example
- Updated utils in `physicsnemo.launch.logging` to avoid unnecessary `wandb` and `mlflow`
  imports
- Moved to experiment-based Hydra config in Lagrangian-MGN example
- Make data caching optional in `MeshDatapipe`
- The use of older `importlib_metadata` library is removed

### Deprecated

- ProcessGroupConfig is tagged for future deprecation in favor of DeviceMesh.

### Fixed

- Update pytests to skip when the required dependencies are not present
- Bug in data processing script in domino training example
- Fixed NCCL_ASYNC_ERROR_HANDLING deprecation warning

### Dependencies

- Remove the numpy dependency upper bound
- Moved pytz and nvtx to optional
- Update the base image for the Dockerfile
- Introduce Multi-Storage Client (MSC) as an optional dependency.
- Introduce `wrapt` as an optional dependency, needed when using
  ShardTensor's automatic domain parallelism

## [0.9.0] - 2024-12-04

### Added

- Graph Transformer processor for GraphCast/GenCast.
- Utility to generate STL from Signed Distance Field.
- Metrics for CAE and CFD domain such as integrals, drag, and turbulence invariances and
  spectrum.
- Added gradient clipping to StaticCapture utilities.
- Bistride Multiscale MeshGraphNet example.
- FIGConvUNet model and example.
- The Transolver model.
- The XAeroNet model.
- Incoporated CorrDiff-GEFS-HRRR model into CorrDiff, with lead-time aware SongUNet and
  cross entropy loss.
- Option to offload checkpoints to further reduce memory usage
- Added StormCast model training and simple inference to examples
- Multi-scale geometry features for DoMINO model.

### Changed

- Refactored CorrDiff training recipe for improved usability
- Fixed timezone calculation in datapipe cosine zenith utility.
- Refactored EDMPrecondSRV2 preconditioner and fixed the bug related to the metadata
- Extended the checkpointing utility to store metadata.
- Corrected missing export of loggin function used by transolver model

## [0.8.0] - 2024-09-24

### Added

- Graph Transformer processor for GraphCast/GenCast.
- Utility to generate STL from Signed Distance Field.
- Metrics for CAE and CFD domain such as integrals, drag, and turbulence invariances and
  spectrum.
- Added gradient clipping to StaticCapture utilities.
- Bistride Multiscale MeshGraphNet example.

### Changed

- Refactored CorrDiff training recipe for improved usability
- Fixed timezone calculation in datapipe cosine zenith utility.

## [0.7.0] - 2024-07-23

### Added

- Code logging for CorrDiff via Wandb.
- Augmentation pipeline for CorrDiff.
- Regression output as additional conditioning for CorrDiff.
- Learnable positional embedding for CorrDiff.
- Support for patch-based CorrDiff training and generation (stochastic sampling only)
- Enable CorrDiff multi-gpu generation
- Diffusion model for fluid data super-resolution (CMU contribution).
- The Virtual Foundry GraphNet.
- A synthetic dataloader for global weather prediction models, demonstrated on GraphCast.
- Sorted Empirical CDF CRPS algorithm
- Support for history, cos zenith, and downscaling/upscaling in the ERA5 HDF5 dataloader.
- An example showing how to train a "tensor-parallel" version of GraphCast on a
Shallow-Water-Equation example.
- 3D UNet
- AeroGraphNet example of training of MeshGraphNet on Ahmed body and DrivAerNet datasets.
- Warp SDF routine
- DLWP HEALPix model
- Pangu Weather model
- Fengwu model
- SwinRNN model
- Modulated AFNO model

### Changed

- Raise `PhysicsNeMoUndefinedGroupError` when querying undefined process groups
- Changed Indexing error in `examples/cfd/swe_nonlinear_pino` for `physicsnemo` loss function
- Safeguarding against uninitialized usage of `DistributedManager`

### Removed

- Remove mlflow from deployment image

### Fixed

- Fixed bug in the partitioning logic for distributing graph structures
intended for distributed message-passing.
- Fixed bugs for corrdiff diffusion training of `EDMv1` and `EDMv2`
- Fixed bug when trying to save DDP model trained through unified recipe

### Dependencies

- Update DALI to CUDA 12 compatible version.
- Update minimum python version to 3.10

## [0.6.0] - 2024-04-17

### Added

- The citation file.
- Link to the CWA dataset.
- ClimateDatapipe: an improved datapipe for HDF5/NetCDF4 formatted climate data
- Performance optimizations to CorrDiff.
- Physics-Informed Nonlinear Shallow Water Equations example.
- Warp neighbor search routine with a minimal example.
- Strict option for loading PhysicsNeMo checkpoints.
- Regression only or diffusion only inference for CorrDiff.
- Support for organization level model files on NGC file system
- Physics-Informed Magnetohydrodynamics example.

### Changed

- Updated Ahmed Body and Vortex Shedding examples to use Hydra config.
- Added more config options to FCN AFNO example.
- Moved posiitonal embedding in CorrDiff from the dataloader to network architecture

### Deprecated

- `physicsnemo.models.diffusion.preconditioning.EDMPrecondSR`. Use `EDMPecondSRV2` instead.

### Removed

- Pickle dependency for CorrDiff.

### Fixed

- Consistent handling of single GPU runs in DistributedManager
- Output location of objects downloaded with NGC file system
- Bug in scaling the conditional input in CorrDiff deterministic sampler

### Dependencies

- Updated DGL build in Dockerfile
- Updated default base image
- Moved Onnx from optional to required dependencies
- Optional Makani dependency required for SFNO model.

## [0.5.0] - 2024-01-25

### Added

- Distributed process group configuration mechanism.
- DistributedManager utility to instantiate process groups based on a process group config.
- Helper functions to faciliate distributed training with shared parameters.
- Brain anomaly detection example.
- Updated Frechet Inception Distance to use Wasserstein 2-norm with improved stability.
- Molecular Dynamics example.
- Improved usage of GraphPartition, added more flexible ways of defining a partitioned graph.
- Physics-Informed Stokes Flow example.
- Profiling markers, benchmarking and performance optimizations for CorrDiff inference.
- Unified weather model training example.

### Changed

- MLFLow logging such that only proc 0 logs to MLFlow.
- FNO given seperate methods for constructing lift and spectral encoder layers.

### Removed

- The experimental SFNO

### Dependencies

- Removed experimental SFNO dependencies
- Added CorrDiff dependencies (cftime, einops, pyspng, nvtx)
- Made tqdm a required dependency

## [0.4.0] - 2023-11-20

### Added

- Added Stokes flow dataset
- An experimental version of SFNO to be used in unified training recipe for
weather models
- Added distributed FFT utility.
- Added ruff as a linting tool.
- Ported utilities from PhysicsNeMo Launch to main package.
- EDM diffusion models and recipes for training and sampling.
- NGC model registry download integration into package/filesystem.
- Denoising diffusion tutorial.

### Changed

- The AFNO input argument `img_size` to `inp_shape`
- Integrated the network architecture layers from PhysicsNeMo-Sym.
- Updated the SFNO model, and the training and inference recipes.

### Fixed

- Fixed physicsnemo.Module `from_checkpoint` to work from custom model classes

### Dependencies

- Updated the base container to PyTorch 23.10.
- Updated examples to use Pydantic v2.

## [0.3.0] - 2023-09-21

### Added

- Added ability to compute CRPS(..., dim: int = 0).
- Added EFI for arbitrary climatological CDF.
- Added Kernel CRPS implementation (kcrps)
- Added distributed utilities to create process groups and orthogonal process groups.
- Added distributed AFNO model implementation.
- Added distributed utilities for communication of buffers of varying size per rank.
- Added distributed utilities for message passing across multiple GPUs.
- Added instructions for docker build on ARM architecture.
- Added batching support and fix the input time step for the DLWP wrapper.

### Changed

- Updating file system cache location to physicsnemo folder

### Fixed

- Fixed physicsnemo uninstall in CI docker image

### Security

- Handle the tar ball extracts in a safer way.

### Dependencies

- Updated the base container to latest PyTorch 23.07.
- Update DGL version.
- Updated require installs for python wheel
- Added optional dependency list for python wheel

## [0.2.1] - 2023-08-08

### Fixed

- Added a workaround fix for the CUDA graphs error in multi-node runs

### Security

- Update `certifi` package version

## [0.2.0] - 2023-08-07

### Added

- Added a CHANGELOG.md
- Added build support for internal DGL
- 4D Fourier Neural Operator model
- Ahmed body dataset
- Unified Climate Datapipe

### Changed

- DGL install changed from pypi to source
- Updated SFNO to add support for super resolution, flexible checkpoining, etc.

### Fixed

- Fixed issue with torch-harmonics version locking
- Fixed the PhysicsNeMo editable install
- Fixed AMP bug in static capture

### Security

- Fixed security issues with subprocess and urllib in `filesystem.py`

### Dependencies

- Updated the base container to latest PyTorch base container which is based on torch 2.0
- Container now supports CUDA 12, Python 3.10

## [0.1.0] - 2023-05-08

### Added

- Initial public release.
